---
path: '/atoms/fileUploadInput/guide'
type: 'intro'
level: 'atoms'
title: 'file upload input'
---

The file upload input element let the user choose one or more files from their device storage.
These selected files can be uploaded to a server through form submission or be manipulated using the Javascript File API.
