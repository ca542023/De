#!/usr/bin/env python3
import sys, random
from can.interfaces.socketcan import SocketcanBus
from uds_server.models import (
    Session,
    SecurityLevel,
    DataItem,
    Context,
    BaseSecurityCryptoProvider,
)
from uds_server.services import (
    BaseServiceInterface,
    DiagnosticSessionControlService,
    TesterPresentService,
    ReadDataByIdentifierService,
    SecurityAccessService,
    ECUReset,
)
from udsoncan.connections import PythonIsoTpConnection
from isotp import Address, AddressingMode, CanStack
from can.interfaces.socketcan import SocketcanBus
from uds_server import UDSServer
from concurrent.futures import ThreadPoolExecutor


def open_bus_interface(name):
    return SocketcanBus(channel=name)


def open_isotp_socket(bus_name, rx_id, tx_id):
    bus = open_bus_interface(bus_name)
    addr = Address(AddressingMode.Normal_11bits, rxid=rx_id, txid=tx_id)
    can_stack = CanStack(bus=bus, address=addr)
    return PythonIsoTpConnection(can_stack)


def run_uds_server(bus_name):
    print("Starting UDS Server.")
    conn = open_isotp_socket(bus_name, 0x5A8, 0x588)

    # Define Sessions
    default_session = Session(0x01, "default_session", is_default_session=True)
    programming_session = Session(0x02, "programming_session")
    sessions = set[Session]([default_session, programming_session])

    # Define the servers allowed Session transistions
    default_session_transition = (
        default_session,
        {default_session, programming_session},
    )
    programming_session_transition = (
        programming_session,
        {default_session, programming_session},
    )
    session_transitions = dict(
        [default_session_transition, programming_session_transition]
    )

    # Define Services
    services = set[BaseServiceInterface](
        [
            DiagnosticSessionControlService(session_transitions=session_transitions),
            TesterPresentService(),
            ReadDataByIdentifierService(),
            SecurityAccessService(max_attempts=500),
            ECUReset(),
        ]
    )

    # define Security Levels
    security_levels = {
        SecurityLevel(1): CH1CryptoProvider(key=b"\x83\x44\xef\x6a\xee\x48\xc4\x8f"),
        SecurityLevel(3): CH2CryptoProvider(),
        SecurityLevel(5): CH3CryptoProvider(key=b"\x01\x0e3\xc8\xc5 7\x85"),
        SecurityLevel(7): CH4CryptoProvider(key=b"\xf7\x15\xc8[N\xb2n+"),
    }

    data_items = {
        DataItem(0xF186, "Get current Session", 0x1234, get_active_session),
        DataItem(0xF282, "Get all supported Sessions", 0x4321, supported_sessions),
        DataItem(
            0x0010,
            "DIDs",
            0x0010,
            b"Get all sessions: f282\n get current session f186\n ??? 00fe",
        ),
        DataItem(
            0x00FE,
            "Secret",
            0xFFFF,
            b"ETAS{cant_hide_anymore_d4mn!}",
            {programming_session},
        ),
        DataItem(0x0002, "Simple DID read", 0x0002, b"ETAS{ke3p_d1gging_ke3p_l00king}"),
        DataItem(
            0xF1D1,
            "SecAccCh1",
            0xFFFF,
            b"etas{4lr1ght_5am3_5ong_h3re_w3_g0!}",
            None,
            (SecurityLevel(1),),
        ),
        DataItem(
            0xF1D2,
            "SecAccCh2",
            0xFFFF,
            b"etas{h4sh_w1thou7_g00d_r4nd0mn3s5}",
            None,
            (SecurityLevel(3),),
        ),
        DataItem(
            0xF1D3,
            "SecAccCh3",
            0xFFFF,
            b"etas{d0nt_r3u5e_k3ys!!}",
            None,
            (SecurityLevel(5),),
        ),
        DataItem(
            0xF1D4,
            "SecAccCh4",
            0xFFFF,
            b"etas{s3n10r_d3v_ski7zz}",
            None,
            (SecurityLevel(7),),
        ),
    }

    # Initialize UDS Server with predefined parts
    uds_server = UDSServer(
        conn=conn,
        sessions=sessions,
        services=services,
        security_levels_unlock=security_levels,
        data_items=data_items,
        session_reset_time=3600,
    )
    uds_server.start()
    print("UDS Server running")


def get_active_session(context: Context) -> bytes:
    return context.active_session.encode()


# noinspection PyUnusedLocal
def supported_sessions(context: Context) -> bytes:
    sessions_output = []
    for session in context.sessions:
        sessions_output.append(session.session_id)

    return b"".join(i.to_bytes(1, "big") for i in sessions_output)


class CH1CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        self.random = random.Random(0xAF)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        randr = self.random.randbytes(8)
        print(randr.hex())
        return randr

    def generate_key(self, seed: bytes):
        return bytes([a ^ b for a, b in zip(seed, self._key)])


class CH2CryptoProvider(BaseSecurityCryptoProvider):
    import hashlib as hashlib

    def __init__(self, key: bytes = None):
        self.random = random.Random(0x2E)
        self.iv = b"\x42"
        super().__init__(None)

    def generate_seed(self, associated_data=None):
        return self.random.randbytes(8)

    def generate_key(self, seed: bytes):
        return self.hashlib.sha256(seed + self.iv).digest()


class CH3CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        self.random = random.Random(0xD0)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        return self.random.randbytes(8)

    def generate_key(self, seed: bytes):
        return bytes([a ^ b for a, b in zip(seed, self._key)])


class CH4CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        self.random = random.Random(0x6A)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        return self.random.randbytes(4)

    def generate_key(self, seed: bytes):
        return bytes([a ^ b for a, b in zip(seed, self._key)])

    def equal(self, chal_1: bytes, chal_2):
        return bytes([a & b for a, b in zip(chal_1, chal_2)]) == chal_1


tasks = [
    run_uds_server,
]


def main():
    bus_name = sys.argv[1]
    threads = []
    with ThreadPoolExecutor() as executor:
        for task in tasks:
            r = executor.submit(task, bus_name)


if __name__ == "__main__":
    main()
