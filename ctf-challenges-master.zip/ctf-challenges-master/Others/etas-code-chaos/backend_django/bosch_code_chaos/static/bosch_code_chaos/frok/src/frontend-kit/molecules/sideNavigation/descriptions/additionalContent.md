---
path: "/molecules/sideNavigation/guide"
type: "additionalContent"
level: "molecules"
title: "Side navigation"
---

### Instance API

The instance API can be accessed by the `component` property of the side navigation element.

| Method   | parameters | description                     |
| -------- | ---------- | ------------------------------- |
| `show()` |            | Will show this side navigation. |
