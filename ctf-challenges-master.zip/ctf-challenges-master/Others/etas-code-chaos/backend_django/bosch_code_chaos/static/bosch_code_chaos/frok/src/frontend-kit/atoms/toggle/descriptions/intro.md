---
path: "/atoms/toggle/guide"
type: "intro"
level: "atoms"
title: "toggle (switch)"
---

This Atom is also known as _switch_. Because of dependencies with JavaScript, the Frontend Kit name is _toggle_.

The _toggle_ element can be used like a checkbox, but supports a label on each side of the element that better describes the choice made by the user. Both labels are optional.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
    Each <code>input</code> can be referenced by multiple <code>labels</code> but the <code>input</code> tag has a unique <code>id</code> that can be paired to only one <code>label</code> (through its same <code>for</code> attribute). <br />
    In other words, according to the <a href="https://www.w3.org/WAI/standards-guidelines/wcag/" target="_self">Web Content Accessibility Guidelines (WCAG)</a>, it is highly recommended to use only <em>one</em> label together with the <code>input</code>.
</div></div>
