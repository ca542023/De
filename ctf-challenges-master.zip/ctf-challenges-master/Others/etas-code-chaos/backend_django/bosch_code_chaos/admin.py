from django.contrib import admin
from .models import SimulatedEmail, CustomUser, EmailVerification, InventoryItem, CTF


admin.site.register(SimulatedEmail)


admin.site.register(EmailVerification)


admin.site.register(InventoryItem)


class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('email', 'security_question_1', 'security_question_2', 'profile_picture')
    fieldsets = (
        ('User Info', {'fields': ('email', 'password', 'security_question_1', 'security_question_2')}),
        ('Profile Picture', {'fields': ('profile_picture',)}),
    )
    exclude = ('first_name', 'last_name')
admin.site.register(CustomUser, CustomUserAdmin)

admin.site.register(CTF)