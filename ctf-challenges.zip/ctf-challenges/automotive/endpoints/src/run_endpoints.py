#!/usr/bin/env python3

import sys

from concurrent.futures import ThreadPoolExecutor

from can_endpoint import tasks as can_tasks
from uds_endpoint import tasks as uds_tasks


def main():
    bus_name = sys.argv[1]
    tasks = can_tasks + uds_tasks
    with ThreadPoolExecutor() as executor:
        for task in tasks:
            r = executor.submit(task, bus_name)


if __name__ == "__main__":
    main()
