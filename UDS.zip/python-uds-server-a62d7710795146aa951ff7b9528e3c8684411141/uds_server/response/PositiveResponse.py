from .BaseResponse import BaseResponse


class PositiveResponse(BaseResponse):

    def __init__(self, service_id, associated_data=None):
        super().__init__(service_id)
        if associated_data and type(associated_data) != int and type(associated_data) != bytes:
            raise ValueError("Expected type int or bytes for associated_data")
        self._associated_data = associated_data

    def encode(self):
        positive_service_id = self._service_id + 64
        resp = positive_service_id.to_bytes(1, 'big')

        if self._associated_data:
            if type(self._associated_data) == int:
                resp += self._associated_data.to_bytes(1, 'big')
            elif type(self._associated_data) == bytes:
                resp += self._associated_data

        return resp
