from flask import render_template
from flask_socketio import SocketIO

from CTFd.utils.decorators import admins_only
from CTFd.plugins.challenges import CHALLENGE_CLASSES
from CTFd.plugins import register_plugin_assets_directory

import os


class WrappedChallenge():

    def __init__(self, inner, sio):
        self._c = inner
        self._sio = sio

    def __getattr__(self, val):
        return self._c.__getattribute__(self._c, val)

    @property
    def templates(self):
        return self._c.templates

    def create(self, request):
        return self._c.create(request)

    def read(self, challenge):
        return self._c.read(challenge)

    def update(self, challenge, request):
        return self._c.update(challenge, request)

    def delete(self, challenge):
        return self._c.delete(challenge)

    def attempt(self, challenge, request):
        status, msg = self._c.attempt(challenge, request)
        return status, msg

    def solve(self, user, team, challenge, request):
        data = {
            "user": user.name,
            "team": team.name if team else '',
            "chal": challenge.name,
            "pts": challenge.value
        }
        self._sio.emit('solve', data)
        return self._c.solve(user, team, challenge, request)

    def fail(self, user, team, challenge, request):
        return self._c.fail(user, team, challenge, request)


def load(app):
    sio = SocketIO()  # Server-side broadcast SocketIO

    for (k, v) in CHALLENGE_CLASSES.items():
        CHALLENGE_CLASSES[k] = WrappedChallenge(v, sio)

    sio.init_app(app, cors_allowed_origins='*')
