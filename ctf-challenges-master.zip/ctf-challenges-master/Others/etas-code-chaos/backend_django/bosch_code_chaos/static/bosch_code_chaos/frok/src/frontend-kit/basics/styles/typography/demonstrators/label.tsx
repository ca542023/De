import * as React from "react";

const LabelDemonstrator: React.FunctionComponent = () => (
    <label>Example label</label>
    )

export default LabelDemonstrator;