# Notifyer - Real-time challenge solve notifications

Uses SocketIO to notify browsers when a new solve happens in real time.
Meant to be used as a browser source in OBS.

## Installation

- Clone into `CTFd/CTFd/plugins/notifyer` (**not** `ctfd-notifyer`)
- In your CTFd virtualenv (or pipenv), run `pip install -r notifyer/requirements.txt` (It's basically just flask-socketio)
- Restart CTFd

## Usage

- Implement socket client handler with e.g.
```javascript
<script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
var socket = io();
socket.on('solve', function(data){
    console.log(data);
});
```


