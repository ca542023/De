package main

import (
	"C"
	"errors"
)

var iv = []byte{0x02, 0x62, 0x5D, 0x12, 0x34, 0x78, 0xCD, 0x56}

//export CreateKeyFromSeed
func CreateKeyFromSeed(seed []byte) ([]byte, error) {
	key := make([]byte, 8)
	if len(seed) != 8 {
		return key, errors.New("illegal seed length")
	}

	// Rotate
	seedRotate := []byte{seed[4], seed[7], seed[1], seed[5], seed[3], seed[0], seed[2], seed[6]}

	// XOR
	for i := range key {
		key[i] = seedRotate[i] ^ iv[i]
	}

	return key, nil
}

/*
 go build -o SeedKey.dll -ldflags "-linkmode external -extldflags -static" -buildmode=c-shared SeedKey.go
func main() {
	// This is a placeholder main function.
	// The main function is not required for creating a DLL.
}
*/
