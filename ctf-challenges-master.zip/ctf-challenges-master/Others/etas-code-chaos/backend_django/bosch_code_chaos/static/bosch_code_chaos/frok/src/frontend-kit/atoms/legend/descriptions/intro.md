---
path: '/atoms/legend/guide'
type: 'intro'
level: 'atoms'
title: 'legend'
---

The `legend` HTML element represents a caption for the content of its parent `fieldset`, providing a caption or title for a group of related form elements.

It enhances accessibility, organization, and improves the overall structure of forms.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
Ensure that an instance of this component is used inside a parent component  with the <code>fieldset</code> tag.
</div></div>
