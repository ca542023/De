---
path: "/atoms/background/guide"
type: "variant"
level: "atoms"
title: "background"
variant: "primary"
---

This class is useful if you need to reset a background color.
