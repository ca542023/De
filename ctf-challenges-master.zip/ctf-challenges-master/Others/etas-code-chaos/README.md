# Important
This is a customized version for the CTF Workshop Service.
The original code can be found [here](https://sourcecode.socialcoding.bosch.com/projects/ETAS_SEC_ECT2/repos/vulnerable-web-app/browse).

# Bosch Code Chaos
The application was developed as part of the bachelor thesis of [Maximilian Fink's](mailto:maximilian.fink2@etas.com) from 09/2023 - 01/2024.

* [Documentation in the internal Confluence](https://inside-docupedia.bosch.com/confluence/pages/viewpage.action?pageId=3815768663)
* [Bachelor Thesis - detailed documentation](https://sites.inside-share4.bosch.com/sites/016055/Documents/Forms/AllItems.aspx?RootFolder=%2Fsites%2F016055%2FDocuments%2FStudents%2FMaximilian%20Fink%2FBachelor%20Thesis)


## Usage

### Local startup with Docker (e.g. for Demos)

Use the makefile to execute Docker commands in an easy way:

* `make build` - builds the Docker container from the code
* `make run` - starts the Docker container with suitable variables
* `make stop` - stops the Docker container
* `make logs` - show the Docker logs


### Startup in the Azure Cloud (e.g. for Hiring Tests)

* Login to the Department's Azure Sandbox
* Choose the "Bosch Code Chaos" Resource Group
* Click "New Resource"
  * Choose "Azure Web App"
  * Configure Container Settings - choose "Bosch Code Chaos" Image
  * Add Authentication "HTTP Basic Auth"
  * Save Changes and wait for Deployment
* Copy the Link


## Local Development


### Requirements

- Python 3.x installed.
- Pip installed (usually included with Python 3.x).


### Setting Up the Virtual Environment

1. Navigate to the project directory:
2. Create a virtual environment (venv): `python3 -m venv venv`
3. Activate the virtual environment:
   * On Windows: `venv\Scripts\activate`
   * On macOS and Linux: `source venv/bin/activate`


### Installing Dependencies

* `pip3 install -r requirements.txt`
  

### Database Configuration

1. `python3 manage.py makemigrations`
2. `python3 manage.py migrate`


### Starting the Development Server

* `python3 manage.py runserver`
*  The project should now be accessible at [http://localhost:8000/](http://localhost:8000/)


### Docker

* Start a local proxy (px etc)
  * Help: https://inside-docupedia.bosch.com/confluence/display/ISCW/Setup+the+internal+proxy+general+use
* Set Docker to use the local proxy, e.g. http://localhost:3128
* `docker build -t bosch_code_chaos:dev .`
* `docker run -d -p 8000:8000 bosch_code_chaos:dev`






---


docker run -d --name bosch_code_chaos -p 9321:80 -e PORT=9321 -e DJANGO_DEBUG=False -e ETAS_BRANDING=True -e SSL=False bosch_code_chaos:production

port nach außen und port port env variable muss gleich sein!