---
path: "/atoms/sticker/guide"
type: "intro"
level: "atoms"
title: "sticker"
---

Stickers can highlight special content such as: features of a product, a promotion.


