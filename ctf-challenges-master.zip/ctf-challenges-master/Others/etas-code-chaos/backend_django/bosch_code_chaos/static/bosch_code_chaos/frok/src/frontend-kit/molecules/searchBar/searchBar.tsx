/* eslint-disable import/prefer-default-export */
import * as React from 'react';
import { Button } from '../../atoms/button/button';
import {
  SearchInput,
  SearchInputProps,
} from '../../atoms/searchInput/searchInput';

/**
 * @name      m-search-bar
 * @type      molecule
 * @author    Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @description
 * representation of search bar
 */

const SearchBar: React.FunctionComponent<SearchInputProps> = ({
  id,
  name,
  placeholder,
  label,
  isDisabled,
  readOnly,
}) => {
  return (
    <div className="m-search-bar">
      <SearchInput
        id={id}
        name={name}
        placeholder={placeholder}
        label={label}
        isDisabled={isDisabled}
        readOnly={readOnly}
      />
      <Button
        mode="primary"
        additionalClasses={['m-search-bar__icon-search']}
        label="Search"
        icon="search"
      />
    </div>
  );
};

export { SearchBar };
