from ..models import (
    Context,
    Session,
    SecurityLevel,
    CommonResponseCodes,
    DownloadUploadJob,
)
from ..models.security.SecurityAccessState import SecurityAccessState
from ..response import BaseResponse, NegativeResponse, PositiveResponse
from ..services.BaseService import BaseServiceInterface


class ECUReset(BaseServiceInterface):
    def __init__(
        self,
        service_id=0x11,
        session_whitelist: set[Session] = None,
        security_level_whitelist: tuple[SecurityLevel] = None,
    ):
        super().__init__(service_id, session_whitelist, security_level_whitelist)

    def run(
        self, context: Context, sub_fun_data: bytes
    ) -> tuple[Context, BaseResponse]:
        if int.from_bytes(sub_fun_data, 'big') == 0x03:
            default_session = None
            for session in context.sessions:
                if session.is_default_session:
                    default_session = session
                    break
            context.active_session = default_session
            context.reset_security_level()
            context.security_access_attempts = 0

            # Re-init to reset internal state of security provider
            for value in context.security_levels_unlock.values():
                value.__init__(value._key)

            context.download_upload_job = DownloadUploadJob()
            return context, PositiveResponse(self.id, sub_fun_data)

        else:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.SUB_FUNCTION_NOT_SUPPORTED
            )
