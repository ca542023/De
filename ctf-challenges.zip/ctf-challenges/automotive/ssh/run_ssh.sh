#!/bin/bash

user=$1
pw=$2
interface=$3
published_port=$4
[[ -z $user || -z $pw || -z $interface || -z $published_port ]] && exit 1

cat <<< "container info -- user: ${user}, pw: ${pw}, interface: ${interface}, published_port: ${published_port}"

regex="${interface}@[^:]+:.*state UP"
echo "Waiting for ${interface} ..."
while read -r line; do
    [[ $line =~ $regex ]] && break
done < <(ip monitor)
echo "${interface} seems to be up!"

chpasswd "$user" <<< "$user:$pw"

service ssh start

sleep infinity
