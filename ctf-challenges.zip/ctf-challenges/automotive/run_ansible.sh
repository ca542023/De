#!/bin/bash
set -e

die () {
    echo "$1" >&2
    [[ -n $2 ]] && usage >&2
    exit 1
}

usage () {
    cat <<EOF
usage: $0 -c PATH [ARGS...] PATH_TO_ANSIBLE_PLAYBOOK

    -c PATH yaml config file
    -h      show this help message and exit
    -r      restart the given playbook
    -s      stop the given playbook

Note: -r and -s are mutually exclusive.
EOF
}

ansible_venv_name="ansible_venv"
restart="false"
stop="false"

while getopts c:hrs opt; do
    case "$opt" in
        "c")
            config_file="$OPTARG"
            ;;
        "h")
            usage; exit 0
            ;;
        "r")
            restart="true"
            ;;
        "s")
            stop="true"
            ;;
        *)
            die "error: invalid command line flag" 1
            ;;
    esac
done

# Check that the mandatory arguments are present.
[[ -z $config_file ]] && die "error: config file not specified" 1
# Verify that "stop" and "restart" are not both set to true.
[[ $restart == "true" && $stop == "true" ]] && die "error: both restart and stop specified" 1
# Discard the parsed options from the argument array.
shift $((OPTIND - 1))
[[ -z $1 ]] && die "error: path to playbook not specified" 1
playbook=$1
# Check for too many arguments.
shift 1
[[ -n $1 ]] && die "error: too many arguments given" 1

# Create virtual environment if not existent.
[[ ! -e $ansible_venv_name ]] && python3 -m venv "$ansible_venv_name"
source "${ansible_venv_name}/bin/activate" || die "error: cannot enter virtual environment ${ansible_venv_name}"

# Install/Upgrade ansible.
pip3 install -U ansible requests

# Collect the additional variables to be passed to ansible on the command line
# as JSON string.
# (Without JSON, every variable value would be interpreted as string.)
vars="{\"restart\": ${restart}, \"stop\": ${stop}}"

# Collect the command line arguments for ansible.
args=(
    "-e" "$vars"
    "-e" "@${config_file}"
)

# Run the given ansible playbook.
ansible-playbook "${args[@]}" "$playbook"
