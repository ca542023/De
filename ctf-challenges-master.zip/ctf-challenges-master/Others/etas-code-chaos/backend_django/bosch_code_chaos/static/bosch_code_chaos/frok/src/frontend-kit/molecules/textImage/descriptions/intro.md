---
path: "/molecules/textImage/guide"
type: "intro"
level: "molecules"
title: "text image"
---

The Text image molecule can be used to show an image inside a copy text block.