---
path: "/atoms/text/guide"
type: "intro"
level: "atoms"
title: "text"
---

For copy text, use the atom as showcased below to have already-correct margins, font-sizes and so on.