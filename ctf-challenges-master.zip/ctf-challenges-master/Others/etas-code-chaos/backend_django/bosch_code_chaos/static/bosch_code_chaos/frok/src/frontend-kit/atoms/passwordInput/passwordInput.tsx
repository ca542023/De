/* eslint-disable import/prefer-default-export */
import * as React from 'react';

interface PasswordInputProps {
  label?: string;
  id: number;
  name: string;
  placeholder?: string;
  isDisabled?: boolean;
  readOnly?: boolean;
}

/**
 * @name      a-password-input
 * @type      atom
 * @author    Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @param   {string} label          Label to Display
 * @param   {number} id             Unique ID for each password input
 * @param   {string} name           Unique name for each password input
 * @param   {string} placeholder    Placeholder of password input
 * @param   {boolean} isDisabled    Wether or not the password input is disabled
 * @param   {boolean} readOnly      Wether or not the password input is read only
 *
 * @description
 * representation of password input
 */

const PasswordInput: React.FunctionComponent<PasswordInputProps> = ({
  label,
  id,
  name,
  placeholder,
  isDisabled,
  readOnly,
}) => {
  const idPasswordInput = `password-input-${id}`;

  return (
    <div className="a-password-input">
      {label && <label htmlFor={idPasswordInput}>{label}</label>}
      <input
        type="password"
        id={idPasswordInput}
        name={name}
        placeholder={placeholder}
        disabled={isDisabled}
        readOnly={readOnly}
      />
    </div>
  );
};

export { PasswordInput };
