import BaseComponent from '../../baseComponent';

const SEARCH_BAR_INPUT_SELECTOR = '.m-search-bar input';
const SEARCH_BAR_CLOSE_BUTTON_SELECTOR = '.a-search-input__icon-close';
const SEARCH_BAR_BUTTON_SELECTOR = '.m-search-bar__icon-search';

export default class SearchBar extends BaseComponent {
  private searchInput: HTMLInputElement;
  private closeButton: HTMLButtonElement;
  private searchButton: HTMLButtonElement;

  constructor(container: HTMLElement) {
    super(container);

    /**
     * Define DOM Elements and Variables
     */
    this.searchInput = this.container.querySelector(SEARCH_BAR_INPUT_SELECTOR);
    this.closeButton = this.container.querySelector(
      SEARCH_BAR_CLOSE_BUTTON_SELECTOR
    );
    this.searchButton = this.container.querySelector(
      SEARCH_BAR_BUTTON_SELECTOR
    );

    if (this.searchButton && !this.searchInput.hasAttribute('readonly'))
      this.searchButton.addEventListener(
        'click',
        this.resetInputAndHideButton.bind(this)
      );
  }

  /**
   * @name hideCloseButton
   * @description
   * Hide the close button
   */
  private hideCloseButton(): void {
    this.closeButton.style.display = 'none';
  }

  /**
   * @name resetInputValue
   * @description
   * Reset the input value
   */
  private resetInputValue(): void {
    this.searchInput.value = '';
  }

  /**
   * @name resetInputAndHideButton
   * @description
   * Reset the input value and hide the close button
   */
  private resetInputAndHideButton(): void {
    this.resetInputValue();
    this.hideCloseButton();
  }
}
