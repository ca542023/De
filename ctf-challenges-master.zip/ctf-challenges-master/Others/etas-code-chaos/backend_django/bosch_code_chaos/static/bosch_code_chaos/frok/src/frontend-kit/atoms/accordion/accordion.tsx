import * as React from 'react';
import classNames from 'classnames';
import { Icon } from '../icon/icon';

class AccordionProps {
  open?: boolean;
  headline: string;
  size?: 'small' | 'large';
  name?: string;
}

/**
 * @name        a-accordion
 * @type        atom
 *
 * @param       open            Whether the Accordion is open or not
 * @param       headline        The headline of the Accordion
 * @param       size            The size of the Accordion
 * @param       name            The name of the Accordion
 * @description
 * representation of a accordion
 */

const Accordion: React.FunctionComponent<AccordionProps> = ({
  open = false,
  headline,
  size = 'large',
  name,
}: AccordionProps) => {
  const divClass = classNames('a-accordion', {
    'a-accordion--open': open,
    'a-accordion--small': size === 'small',
  });

  return (
    <div className={divClass}>
      <div className="a-accordion__headline">
        <h2 className="a-accordion__headline-heading highlight">{headline}</h2>
        <button
          id={name}
          type="button"
          className="a-accordion__headline-button"
          aria-expanded="false"
          aria-controls={`content headline button ${name}`}
        >
          {open ? (
            <Icon
              iconName="up"
              className="a-accordion__headline-icon"
              titleText="arrow up"
            />
          ) : (
            <Icon
              iconName="down"
              className="a-accordion__headline-icon"
              titleText="arrow down"
            />
          )}
        </button>
      </div>
      <div
        className="a-accordion__content"
        id={`content ${name}`}
        role="region"
        aria-labelledby={`content ${name}`}
      >
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione
        quibusdam blanditiis recusandae labore veritatis, rem at voluptates vero
        reprehenderit tempore?
      </div>
    </div>
  );
};

export { Accordion, AccordionProps };
