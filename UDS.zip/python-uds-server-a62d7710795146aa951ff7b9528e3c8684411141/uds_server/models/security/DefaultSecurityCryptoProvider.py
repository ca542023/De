from .BaseSecurityCryptoProvider import BaseSecurityCryptoProvider
import os
from Crypto.Hash import SHA256, HMAC


class DefaultSecurityCryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes = b"\x01\x02\x03\x04"):
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        return os.urandom(4)

    def generate_key(self, seed: bytes):
        h = HMAC.new(self._key, digestmod=SHA256)
        h.update(seed)
        return h.digest()
