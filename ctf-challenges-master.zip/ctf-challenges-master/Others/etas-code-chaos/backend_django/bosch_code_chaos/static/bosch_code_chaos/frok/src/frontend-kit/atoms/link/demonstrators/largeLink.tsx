import * as React from 'react';
import { Link } from '../link';

const LargeLinkDemonstrator: React.FunctionComponent = () => (
  <div className="-size-3xl">
    <Link level="primary" label="Link label" href="#" />
  </div>
);

export default LargeLinkDemonstrator;
