import docker
import re
import requests
import json


# Set CTFd URL and TOKEN
ctfd_host = "http://localhost:8000/api/v1/"
docker_host_ip = "192.168.178.147" # The ip where the automotive challenges are accessible for the participants
token = "ctfd_f01d2a45f207f4709c0d710cc55b70c2fc7312de8332792699909338515b44f3"  # Ersetze dies durch deinen tatsächlichen Token

client = docker.from_env()

# Try get ssh (automotive challenge hub) docker container credentials
containers = client.containers.list(filters={'ancestor':'etasctfjail'})
entries = []

for r in containers:
	entries.append(r.logs())

# Add retrieved credentials as tuple to a list
creds = []
for e in entries:
	line = e.decode().split("\n")[0]
	matches = re.findall(r'user: (\w+)|pw: (\w+)|published_port: (\d+)', line)	
	creds.append((''.join(match) for match in matches))	

# General headers
headers = {
    'Authorization': f'Token {token}',
    'Content-Type': 'application/json'
}

# Get registered users in ctfd
response = requests.get(ctfd_host+"users", headers=headers)
users = response.json()['data']

if len(creds) < len(users):
	print('More participants than started docker container.')
	exit(1)
	
for i, user in enumerate(users):
	name, pw, port = creds[i]
	# write creds as comment
	data = {"fields":[{"field_id":2,"value":f"$ssh {name}@{docker_host_ip} -p {port} \n with password {pw}."}]}

	# Sende die POST-Anfrage
	print(ctfd_host+'users/'+str(user['id']))
	response = requests.patch(ctfd_host+'users/'+str(user['id']), headers=headers, data=json.dumps(data))
	print(response)
