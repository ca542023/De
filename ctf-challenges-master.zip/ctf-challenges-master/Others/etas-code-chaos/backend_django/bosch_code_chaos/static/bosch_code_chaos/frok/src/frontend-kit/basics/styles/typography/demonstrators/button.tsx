import * as React from "react";

const ButtonDemonstrator: React.FunctionComponent = () => (
    <button>Example button</button>
    )

export default ButtonDemonstrator;