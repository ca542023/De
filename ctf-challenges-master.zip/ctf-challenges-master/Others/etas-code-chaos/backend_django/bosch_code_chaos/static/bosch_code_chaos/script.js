// DARK MODE
function toggleDarkMode() {
    const body = document.body;
    const isDarkMode = body.classList.contains('-dark-mode');
    
    if (isDarkMode) {
        body.classList.remove('-dark-mode');
        localStorage.setItem('darkMode', 'false');
    } else {
        body.classList.add('-dark-mode');
        localStorage.setItem('darkMode', 'true');
    }
}

const darkModeToggle = document.getElementById('darkModeToggle');
darkModeToggle.addEventListener('click', toggleDarkMode);

const isDarkModeStored = localStorage.getItem('darkMode');
if (isDarkModeStored === 'true') {
    document.body.classList.add('-dark-mode');
}


// COPYRIGHT YEAR
document.getElementById("year").innerHTML = new Date().getFullYear();


// SCROLL TO TOP BUTTON
document.getElementById('toTop').addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
