import * as React from "react";

const H1Demonstrator: React.FunctionComponent = () => (
    <h1>Example headline</h1>
    )

export default H1Demonstrator;