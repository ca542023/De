import BaseComponent from '../../baseComponent';
import ElementWithComponent from '../../ElementWithComponent';
import EscapeKeyHelper from '../../helpers/escapeKey.helper';
import Popover from '../../molecules/popover';
import { ArrowPosition } from '../../molecules/popover/constants';

const CLASS_OPEN = '-open';

/**
 * closes the given menu entry
 */
const close = (entry: Element): void => {
  entry.parentElement.classList.remove(CLASS_OPEN);
  entry.setAttribute('aria-expanded', 'false');
};

/**
 * close all of the listed entries
 */
const closeAll = (navigationEntries: HTMLElement[]): void => {
  navigationEntries.forEach(close);
};

export default class ContextMenu extends BaseComponent {
  private accordions: HTMLButtonElement[];
  private menus: HTMLUListElement[];
  private arrowIcons: HTMLElement[];
  private contextMenuTriggerOpen: HTMLButtonElement;
  private contextMenuTriggerClose: HTMLButtonElement;
  private popoverElement: ElementWithComponent<Popover>;
  private popover: Popover;
  private escapeKeyHelper: EscapeKeyHelper;

  constructor(container: HTMLElement) {
    super(container);

    this.escapeKeyHelper = new EscapeKeyHelper(
      this.close.bind(this),
      this.isOpen.bind(this),
    );

    this.contextMenuTriggerOpen = container.querySelector(
      '.o-context-menu__trigger[data-frok-action="open"]',
    );

    this.contextMenuTriggerClose = container.querySelector(
      '.o-context-menu__trigger[data-frok-action="close"]',
    );

    this.accordions = Array.from(
      container.querySelectorAll('.a-menu-item__group'),
    );

    this.menus = Array.from(container.querySelectorAll('.a-menu-item'));

    this.popoverElement = container.querySelector('.m-popover');
    this.popover = new Popover(this.popoverElement);

    this.arrowIcons = Array.from(
      container.querySelectorAll('.a-icon.boschicon-bosch-ic-down'),
    );

    /**
     * Define Events
     */

    // The button logic: Clicking it will show the context menu, clicking again will hide it again.
    if (this.contextMenuTriggerOpen || this.contextMenuTriggerClose) {
      this.contextMenuTriggerOpen.addEventListener('click', () => {
        this.open();
      });

      this.contextMenuTriggerClose.addEventListener('click', () => {
        this.close();
      });
    }

    // The accordion logic: If I click an accordion it'll open while closing previously opened accordions.
    // If I click again it'll closes the accordion.
    this.accordions.forEach((accordion) => {
      accordion.addEventListener('click', () => {
        const arrowIconTitle = accordion.querySelector(
          '.a-icon.boschicon-bosch-ic-down',
        );

        if (accordion.parentElement.classList.contains(CLASS_OPEN)) {
          accordion.parentElement.classList.remove(CLASS_OPEN);
          arrowIconTitle.setAttribute('title', 'arrow down');
          accordion.setAttribute('aria-expanded', 'false');
        } else {
          closeAll(this.accordions);
          this.arrowIcons.forEach((arrowIcon) => {
            arrowIcon.setAttribute('title', 'arrow down');
          });
          accordion.parentElement.classList.add(CLASS_OPEN);
          arrowIconTitle.setAttribute('title', 'arrow up');
          accordion.setAttribute('aria-expanded', 'true');
        }
      });
    });

    document.addEventListener('click', (event) => {
      if (!event.composedPath().includes(this.container)) {
        this.close();
      }
    });
  }

  public open(): void {
    this.container.classList.add(CLASS_OPEN);
    this.popover.attach(this.contextMenuTriggerClose, this.container);
    this.popover.show();
    this.escapeKeyHelper.enable();
  }

  public close(): void {
    this.container.classList.remove(CLASS_OPEN);
    this.popover.hide();
    closeAll(this.accordions);
    closeAll(this.menus);
    this.escapeKeyHelper.disable();
  }

  public setPosition(position: ArrowPosition): void {
    this.popover.setPosition(position);
  }

  public isOpen(): boolean {
    return this.container.classList.contains(CLASS_OPEN);
  }
}
