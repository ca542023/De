from ..models.Context import Context, Session, SecurityLevel
from ..response import BaseResponse
from ..services.BaseService import BaseServiceInterface


class RequestTransferExitService(BaseServiceInterface):
    def __init__(
        self,
        requestSID: int = 0x37,
        session_whitelist: set[Session] = None,
        security_level_whitelist: tuple[SecurityLevel] = None,
    ):
        # Service is available in every session and by every security level
        super().__init__(requestSID, session_whitelist, security_level_whitelist)

    def run(
        self, context: Context, sub_func_data: bytes
    ) -> tuple[Context, BaseResponse]:
        raise NotImplementedError()
