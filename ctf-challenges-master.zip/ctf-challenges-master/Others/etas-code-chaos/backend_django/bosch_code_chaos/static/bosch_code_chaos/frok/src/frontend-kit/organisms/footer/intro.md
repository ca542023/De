---
path: "/organisms/footer/guide"
type: "intro"
level: "organisms"
title: "Footer"
---

The footer is meant to be the last visual element of every page. The social share functionality depends heavily on your project setup and therefore is not implemented here. The same holds for the search function, which is just a visual placeholder.
