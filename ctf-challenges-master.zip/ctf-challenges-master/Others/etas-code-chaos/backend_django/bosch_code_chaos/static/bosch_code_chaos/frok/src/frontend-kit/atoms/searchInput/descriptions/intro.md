---
path: '/atoms/searchInput/guide'
type: 'intro'
level: 'atoms'
title: 'search input'
---

The search input element let the user enter search queries into.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
According to the <a href="https://www.w3.org/WAI/standards-guidelines/wcag/" target="_self">Web Content Accessibility Guidelines (WCAG)</a>, it is highly reccomended to use a label together with the search input.
</div></div>
