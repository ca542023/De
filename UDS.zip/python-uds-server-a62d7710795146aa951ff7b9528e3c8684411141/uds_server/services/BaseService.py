from abc import ABC, abstractmethod
from ..models import SecurityLevel
from ..models import Session, Context
from ..response import BaseResponse


class BaseServiceInterface(ABC):
    def __init__(
        self,
        service_id,
        session_whitelist: set[Session],
        security_level_whitelist: tuple[SecurityLevel],
    ):
        self.id = service_id
        # Specifies for which Diagnostic Session the service is allowed, if None than the service is active for every
        # possible Diagnostic Session
        self.session_whitelist = session_whitelist
        # Specifies for which Security Level the service is allowed, if None than the service is active for every
        # possible Security Level
        self.security_level_whitelist = security_level_whitelist
        self._is_suppress_positive_resp_bit = False

    @property
    def id(self):
        return self._service_id

    @id.setter
    def id(self, value):
        self._service_id = value

    def is_suppress_positive_resp_bit(self) -> bool:
        return self._is_suppress_positive_resp_bit

    def set_suppress_positive_resp_bit(self, value):
        if value > 127:
            self._is_suppress_positive_resp_bit = True
        else:
            self._is_suppress_positive_resp_bit = False

    # TODO return NRC or 0 if successfull as wrapper class object
    @abstractmethod
    def run(
        self, context: Context, sub_func_data: bytes
    ) -> tuple[Context, BaseResponse]:
        pass
