---
path: '/atoms/colorInput/guide'
type: 'intro'
level: 'atoms'
title: 'color input'
---

The color input element let the user specify a color by using a visual color picker interface.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
According to the <a href="https://www.w3.org/WAI/standards-guidelines/wcag/" target="_self">Web Content Accessibility Guidelines (WCAG)</a>, it is highly reccomended to use a label together with the color input.
</div></div>
<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
Attention Safari Users: We regret to inform you that there is a <a href="https://stackoverflow.com/questions/1848390/safari-ignoring-tabindex" target="_self">known issue</a> with the tabbing functionality in Safari, causing this component to not receive focus as intended. Please be aware of this limitation while navigating this component using the "Tab" key.
</div></div>
