from enum import Enum


class DownloadUploadJob:
    class DownloadUploadStates(Enum):
        free = 0,
        ready = 1,
        running = 2,

    def __init__(self, start_address: int = None, total_size: int = None):
        self.current_state = self.DownloadUploadStates.free
        self.start_address = start_address
        self.total_size = total_size

    @property
    def _start_address(self):
        return self._start_address

    @_start_address.setter
    def _start_address(self, value):
        self._start_address = value

    @property
    def _total_size(self):
        return self._total_size

    @_total_size.setter
    def _total_size(self, value):
        self._total_size = value

    @property
    def _current_state(self):
        return self._current_state

    @_current_state.setter
    def _current_state(self, value):
        self._current_state = value
