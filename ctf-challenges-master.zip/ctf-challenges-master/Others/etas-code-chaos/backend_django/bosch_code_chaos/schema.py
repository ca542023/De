import graphene
from graphene_django.types import DjangoObjectType
from .models import InventoryItem, CustomUser
from .utils import get_flag_by_id, mark_challenge_as_found


# GraphQL Endpoint


class InventoryItemType(DjangoObjectType):
    class Meta:
        model = InventoryItem


class Query(graphene.ObjectType):
    inventory_item = graphene.Field(InventoryItemType, id=graphene.ID())

    def resolve_inventory_item(self, info, id):
        try:
            item = InventoryItem.objects.get(pk=id)
            current_user = info.context.user

            if item.created_by != current_user: 
                # GraphQL IDOR Flag
                flag = get_flag_by_id(7)
                mark_challenge_as_found(7)
                item.name = f"{item.name} {flag}"

            return item
        except InventoryItem.DoesNotExist:
            return None 

schema = graphene.Schema(query=Query)



