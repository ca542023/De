// eslint-disable-next-line no-use-before-define
import * as React from 'react';

interface TileProps {
  name: string;
  background?: 'secondary' | 'contrast';
  fill?: 'purple' | 'blue' | 'turquoise' | 'green';
  children?: React.ReactNode;
}

/**
 * @name        a-tile
 * @type        atom
 *
 * @param       {string}          name          Tile's name.
 * @param       {string}          background    Tile's background. Optional.
 * @param       {string}          fill          Tile's fill color. Default is 'plain'. Optional.
 * @param       {React.ReactNode} children      Tile's optional children.

 * @description
 * representation of tile
 */

const Tile: React.FunctionComponent<TileProps> = ({
  name,
  background,
  fill,
  children,
}) => {
  let tileClass;

  if (background) {
    tileClass = `-${background}`;
  } else if (fill) {
    tileClass = `-${fill}`;
  } else {
    tileClass = '';
  }

  return (
    <div className={`a-tile ${tileClass}`}>
      <a
        href="/#"
        aria-label={`Link for ${name}`}
        className="a-tile__link"
        target="_blank"
      >
        {children}
      </a>
    </div>
  );
};

export { Tile, TileProps };
