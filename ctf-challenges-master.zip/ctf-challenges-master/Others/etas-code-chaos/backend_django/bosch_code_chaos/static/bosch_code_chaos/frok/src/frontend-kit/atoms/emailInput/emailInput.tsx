/* eslint-disable import/prefer-default-export */
import * as React from 'react';

interface EmailInputProps {
  label?: string;
  id: number;
  name: string;
  placeholder?: string;
  isDisabled?: boolean;
  readOnly?: boolean;
}

/**
 * @name      a-email-input
 * @type      atom
 * @author    Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @param   {string} label          Label to Display
 * @param   {number} id             Unique ID for each email input
 * @param   {string} name           Unique name for each email input
 * @param   {string} placeholder    Placeholder of email input
 * @param   {boolean} isDisabled    Wether or not the email input is disabled
 * @param   {boolean} readOnly      Wether or not the email input is read only
 *
 * @description
 * representation of email input
 */

const EmailInput: React.FunctionComponent<EmailInputProps> = ({
  label,
  id,
  name,
  placeholder,
  isDisabled,
  readOnly,
}) => {
  const idEmailInput = `email-input-${id}`;

  return (
    <div className="a-email-input">
      {label && <label htmlFor={idEmailInput}>{label}</label>}
      <input
        type="email"
        id={idEmailInput}
        name={name}
        placeholder={placeholder}
        disabled={isDisabled}
        readOnly={readOnly}
      />
    </div>
  );
};

export { EmailInput };
