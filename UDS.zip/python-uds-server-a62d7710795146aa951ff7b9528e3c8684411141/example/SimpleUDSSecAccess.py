import can, random
from uds_server.models import (
    Session,
    SecurityLevel,
    DataItem,
    Context,
    BaseSecurityCryptoProvider,
    DefaultSecurityCryptoProvider,
)
from uds_server.services import (
    BaseServiceInterface,
    DiagnosticSessionControlService,
    TesterPresentService,
    ReadDataByIdentifierService,
    SecurityAccessService,
    ECUReset,
)
from udsoncan.connections import PythonIsoTpConnection
import isotp
from can.interfaces.socketcan import SocketcanBus
from uds_server import UDSServer

isotp_params = {
    "stmin": 32,
    # Will request the sender to wait 32ms between consecutive frame. 0-127ms or 100-900ns with values from 0xF1-0xF9
    "blocksize": 0,  # Request the sender to send 8 consecutives frames before sending a new flow control message
    "wftmax": 0,  # Number of wait frame allowed before triggering an error
    "tx_data_length": 8,  # Link layer (CAN layer) works with 8 byte payload (CAN 2.0)
    "tx_data_min_length": None,
    # Minimum length of CAN messages. When different from None, messages are padded to meet this length. Works with CAN 2.0 and CAN FD.
    "tx_padding": 0,  # Will pad all transmitted CAN messages with byte 0x00.
    "rx_flowcontrol_timeout": 2000,  # Triggers a timeout if a flow control is awaited for more than 1000 milliseconds
    "rx_consecutive_frame_timeout": 1000,
    # Triggers a timeout if a consecutive frame is awaited for more than 1000 milliseconds
    "squash_stmin_requirement": False,
    # When sending, respect the stmin requirement of the receiver. If set to True, go as fast as possible.
    "max_frame_size": 4095,  # Limit the size of receive frame.
    "listen_mode": False,
}


def main():
    bus = SocketcanBus(channel="vcan0")
    tp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits, 0x102, 0x101)
    stack = isotp.CanStack(bus=bus, address=tp_addr)
    conn = PythonIsoTpConnection(stack)
    # Define Sessions
    default_session = Session(0x01, "default_session", is_default_session=True)
    programming_session = Session(0x02, "programming_session")
    sessions = set[Session]([default_session, programming_session])

    # Define the servers allowed Session transistions
    default_session_transition = (
        default_session,
        {default_session, programming_session},
    )
    programming_session_transition = (
        programming_session,
        {default_session, programming_session},
    )
    session_transitions = dict(
        [default_session_transition, programming_session_transition]
    )

    # Define Services
    services = set[BaseServiceInterface](
        [
            DiagnosticSessionControlService(session_transitions=session_transitions),
            TesterPresentService(),
            ReadDataByIdentifierService(),
            SecurityAccessService(max_attempts=500),
            ECUReset(),
        ]
    )

    # define Security Levels
    security_levels = {
        SecurityLevel(1): CH1CryptoProvider(key=b"\x83\x44\xef\x6a\xee\x48\xc4\x8f"),
        SecurityLevel(3): CH2CryptoProvider(),
        SecurityLevel(5): CH3CryptoProvider(key=b"\x01\x0e3\xc8\xc5 7\x85"),
        SecurityLevel(7): CH4CryptoProvider(key=b"\xf7\x15\xc8[N\xb2n+"),
    }
    data_items = {
        DataItem(0xF186, "Get current Session", 0x1234, get_current_session),
        DataItem(0xF282, "Get all supported Sessions", 0x4321, supported_sessions),
        DataItem(
            0xF1D1,
            "SecAccCh1",
            0xFFFF,
            b"flag{CH1_DEMOFLAG_CHANGE_PLS}",
            None,
            (SecurityLevel(1),),
        ),
        DataItem(
            0xF1D2,
            "SecAccCh2",
            0xFFFF,
            b"flag{CH2_DEMOFLAG_CHANGE_PLS}",
            None,
            (SecurityLevel(3),),
        ),
        DataItem(
            0xF1D3,
            "SecAccCh3",
            0xFFFF,
            b"flag{CH3_DEMOFLAG_CHANGE_PLS}",
            None,
            (SecurityLevel(5),),
        ),
        DataItem(
            0xF1D4,
            "SecAccCh4",
            0xFFFF,
            b"flag{CH4_DEMOFLAG_CHANGE_PLS}",
            None,
            (SecurityLevel(7),),
        ),
    }

    # Initialize UDS Server with predefined parts
    uds_server = UDSServer(
        conn=conn,
        sessions=sessions,
        services=services,
        security_levels_unlock=security_levels,
        data_items=data_items,
        session_reset_time=3600,
    )
    uds_server.start()


def get_current_session(context: Context) -> bytes:
    return context.active_session.encode()


# noinspection PyUnusedLocal
def supported_sessions(context: Context) -> bytes:
    sessions_output = []
    for session in context.sessions:
        sessions_output.append(session.session_id)

    return b"".join(i.to_bytes(1, "big") for i in sessions_output)


class CH1CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        self.random = random.Random(0xAF)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        randr = self.random.randbytes(8)
        print(randr.hex())
        return randr

    def generate_key(self, seed: bytes):
        return bytes([a ^ b for a, b in zip(seed, self._key)])


class CH2CryptoProvider(BaseSecurityCryptoProvider):
    import hashlib as hashlib

    def __init__(self, key: bytes = None):
        self.random = random.Random(0x2E)
        self.iv = b"\x42"
        super().__init__(None)

    def generate_seed(self, associated_data=None):
        return self.random.randbytes(8)

    def generate_key(self, seed: bytes):
        return self.hashlib.sha256(seed + self.iv).digest()


class CH3CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        self.random = random.Random(0xD0)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        return self.random.randbytes(8)

    def generate_key(self, seed: bytes):
        return bytes([a ^ b for a, b in zip(seed, self._key)])


class CH4CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        self.random = random.Random(0x6A)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        return self.random.randbytes(4)

    def generate_key(self, seed: bytes):
        return bytes([a ^ b for a, b in zip(seed, self._key)])

    def equal(self, chal_1: bytes, chal_2):
        return bytes([a & b for a, b in zip(chal_1, chal_2)]) == chal_1


if __name__ == "__main__":
    main()
