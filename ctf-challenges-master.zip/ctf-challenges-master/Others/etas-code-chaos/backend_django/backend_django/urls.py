from django.contrib import admin
from django.urls import path, include
from bosch_code_chaos import views
from django.conf import settings


handler404 = views.custom_404_view 

urlpatterns = [
    path('', include('bosch_code_chaos.urls')), 
]

if settings.DEBUG:
    urlpatterns += [
        path('admin/', admin.site.urls),
    ]