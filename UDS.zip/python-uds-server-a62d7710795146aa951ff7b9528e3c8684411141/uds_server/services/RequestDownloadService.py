from ..models import Session, SecurityLevel, Context, CommonResponseCodes
from ..response import BaseResponse, NegativeResponse, PositiveResponse
from ..services.BaseService import BaseServiceInterface


class RequestDownloadService(BaseServiceInterface):
    def __init__(
        self,
        requestSID: int = 0x34,
        max_number_of_block_length: int = 512,
        session_whitelist: set[Session] = None,
        security_level_whitelist: tuple[SecurityLevel] = None,
    ):
        # Service is available in every session and by every security level
        super().__init__(requestSID, session_whitelist, security_level_whitelist)

        if max_number_of_block_length > 0xF0:
            raise ValueError("Exceeded max size (0xf0) for maxNumberOfBlockLength")
        if max_number_of_block_length & 0x0F != 0:
            raise ValueError(
                "Invalid value for maxNumberOfBlockLength. Must be multiple of 16."
            )
        self.max_number_of_block_length = max_number_of_block_length

    def run(
        self, context: Context, sub_func_data: bytes
    ) -> tuple[Context, BaseResponse]:
        if (
            context.download_upload_job._current_state
            != context.download_upload_job.DownloadUploadStates.free
        ):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUEST_SEQUENCE_ERROR
            )

        # check min length
        if len(sub_func_data) < 4:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT
            )

        dataFormatIdentifier = sub_func_data[0]
        compressionMethod = dataFormatIdentifier & 0xF0
        encryptingMethod = dataFormatIdentifier & 0x0F
        # TODO: handle compression and encryption method by variable handler than are given from the outside (
        #  compress/decompress, enc/dec)
        addressAndLengthFormatIdentifier = sub_func_data[1]
        memoryAddressLength = addressAndLengthFormatIdentifier & 0x0F
        memorySizeLength = addressAndLengthFormatIdentifier & 0xF0
        if (
            addressAndLengthFormatIdentifier <= 0
            or memoryAddressLength <= 0
            or memorySizeLength <= 0
        ):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUEST_OUT_OF_RANGE
            )

        memoryAddress = sub_func_data[2 : 2 + memoryAddressLength]
        memorySize = sub_func_data[
            2 + memoryAddressLength : 2 + memoryAddressLength + memorySizeLength
        ]

        if (
            len(memorySize) + len(memoryAddress)
            != memoryAddressLength + memorySizeLength
        ):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT
            )

        # Check if memory address and size is mapped to a frame and is writeable
        try:
            context.memory.read(address=memoryAddress, length=memorySize)
            context.memory.write(address=memoryAddress, data=bytes(memorySize))
        except ValueError:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUEST_OUT_OF_RANGE
            )

        # init download_upload job that lives in context object and has its own state machine
        context.download_upload_job._start_address = memoryAddress
        context.download_upload_job._total_size = memorySize
        context.download_upload_job._current_state = (
            context.download_upload_job.DownloadUploadStates.ready
        )

        return context, PositiveResponse(self.id, self.max_number_of_block_length)
