<!--
    - Version: 1.0.1

    - The canonical source for this template is: https://bitbucket.intranet.escrypt.com/bitbucket/projects/PT/repos/template/browse/CHANGELOG.md. Changes to the template should only be made there and propagated to the respective repositories.
-->

# Changelog

All notable changes to this project will be documented in this file.

<!-- Please take the following two remarks seriously. Have a quick look at 'Keep a Changelog', it's really simple. The same goes for Semantic Versioning: Spend one minute (literally!) to read the summary and save everyone else the pain of inconsistent version numbers. -->
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<!-- This section is intended to keep track of not yet released changes. Ideally you should include the entry describing your changes here with the same commit that introduces the changes themselves. -->

<!-- Add a new section for each release. Adapt version number and date and remove subsections that are not required. -->
<!-- EXAMPLE

## [0.2.1] - 2023-12-05

### Added

- RequestDownload
- Simple memory layer

### Changed

- Bugfixes and improvements for multiple services

### Removed

- Something not required.

### Fixed

- Something buggy.
-->
# Pre-Releases
## [0.2.1] - 2023-12-05

### Added

- RequestDownload
- Simple memory layer

### Changed

- Bugfixes and improvements for multiple services


### Fixed

- Lot of minor and major fixes.

<!-- The following two subsections are probably not needed very often. Just don't forget about them. -->
<!-- ### Deprecated -->
<!-- ### Security -->
