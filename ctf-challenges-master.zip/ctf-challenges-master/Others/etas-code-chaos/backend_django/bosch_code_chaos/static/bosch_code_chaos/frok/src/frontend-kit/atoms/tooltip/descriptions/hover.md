---
path: "/atoms/tooltip/guide"
type: "variant"
level: "atoms"
title: "tooltip"
variant: "show tooltip on hover"
---

If you do not want to deal with JavaScript, here are some examples for using a hover tooltip without any JS involved. Tweak the `top` and `bottom` values to your needs!

<div class="frontend-kit__notification a-notification -warning"><i class="a-ui-icon a-ui-icon--ui-ic-warning"></i><div class="a-notification__content">
    Please ensure that this approach satisfies your accessibility requirements first.
</div></div>
