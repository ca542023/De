#!/usr/bin/env python3
import sys
from can.interfaces.socketcan import SocketcanBus
from can import Message
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from udsoncan.connections import PythonIsoTpConnection
from isotp import Address, CanStack, AddressingMode
from base64 import b64encode
from random import randbytes


def open_bus_interface(name):
    return SocketcanBus(channel=name)


def open_isotp_socket(bus_name, rx_id, tx_id):
    bus = open_bus_interface(bus_name)
    addr = Address(AddressingMode.Normal_11bits, rxid=rx_id, txid=tx_id)
    can_stack = CanStack(bus=bus, address=addr)
    return PythonIsoTpConnection(can_stack)


def run_simple_send_task(bus_name):
    flag = b"etas{g0odB0y!!!}"
    bus = open_bus_interface(bus_name)

    print(f"Starting simple send task")

    while True:
        for i in range(0, 40):
            bus_send(bus, randbytes(8))
            time.sleep(0.1)

        for part in (flag[:8], flag[8:]):
            bus_send(bus, part)
            time.sleep(0.1)


def bus_send(bus, data):
    bus.send(
        Message(arbitration_id=0x123, is_fd=False, is_extended_id=False, data=data)
    )


def run_isotp_socket(bus_name):
    print("starting simple ISO-TP socket")
    iso_socket = open_isotp_socket(bus_name, 0x6A8, 0x688)
    iso_socket.open()

    while True:
        frame = iso_socket.wait_frame()
        if frame is None:
            continue

        iso_socket.send(b64encode(b"Have a flag: etas{what_is_iso_something??}"))


tasks = [
    run_simple_send_task,
    run_isotp_socket,
]


def main():
    bus_name = sys.argv[1]

    threads = []
    with ThreadPoolExecutor() as executor:
        for task in tasks:
            r = executor.submit(task, bus_name)


if __name__ == "__main__":
    main()
