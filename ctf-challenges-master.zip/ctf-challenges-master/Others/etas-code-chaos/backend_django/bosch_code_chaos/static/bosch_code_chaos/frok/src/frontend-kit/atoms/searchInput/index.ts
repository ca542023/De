import BaseComponent from '../../baseComponent';

const SEARCH_INPUT_SELECTOR = '.a-search-input input';
const SEARCH_INPUT_CLOSE_BUTTON_SELECTOR = '.a-search-input__icon-close';

export default class SearchInput extends BaseComponent {
  private searchInput: HTMLInputElement;
  private closeButton: HTMLButtonElement;

  constructor(container: HTMLElement) {
    super(container);

    /**
     * Define DOM Elements and Variables
     */
    this.searchInput = this.container.querySelector(SEARCH_INPUT_SELECTOR);
    this.closeButton = this.container.querySelector(
      SEARCH_INPUT_CLOSE_BUTTON_SELECTOR
    );

    if (this.searchInput)
      this.searchInput.addEventListener('input', this.handleInput.bind(this));

    if (this.closeButton)
      this.closeButton.addEventListener(
        'click',
        this.resetInputAndHideButton.bind(this)
      );
  }

  /**
   * @name handleInput
   * @description
   * Show or hide the close button based on input
   */
  private handleInput(): void {
    if (this.searchInput.value.trim() !== '') {
      this.showCloseButton();
    } else {
      this.hideCloseButton();
    }
  }

  /**
   * @name hideCloseButton
   * @description
   * Hide the close button
   */
  private hideCloseButton(): void {
    this.closeButton.style.display = 'none';
  }

  /**
   * @name showCloseButton
   * @description
   * Show the close button
   */
  private showCloseButton(): void {
    this.closeButton.style.display = 'flex';
  }

  /**
   * @name resetInputValue
   * @description
   * Reset the input value
   */
  private resetInputValue(): void {
    this.searchInput.value = '';
  }

  /**
   * @name resetInputAndHideButton
   * @description
   * Reset the input value and hide the close button
   */
  private resetInputAndHideButton(): void {
    this.resetInputValue();
    this.hideCloseButton();
  }
}
