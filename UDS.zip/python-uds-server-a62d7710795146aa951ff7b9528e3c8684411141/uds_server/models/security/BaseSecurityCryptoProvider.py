from abc import abstractmethod, ABC


class BaseSecurityCryptoProvider(ABC):
    def __init__(self, key: bytes):
        self._key = key

    @abstractmethod
    def generate_seed(self, associated_data: bytes = None) -> bytes:
        pass

    @abstractmethod
    def generate_key(self, seed: bytes) -> bytes:
        pass

    def equal(self, chal_1: bytes, chal_2: bytes):
        return chal_1 == chal_2

    def provider_implements_equal(self):
        return getattr(self, "equal").__func__ is not getattr(
            BaseSecurityCryptoProvider, "equal"
        )
