package com.example.log4shell;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@WebServlet(name = "loginServlet", value = "/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userName = req.getParameter("uname");
        String password = req.getParameter("password");

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        if (userName.equals("admin") && password.equals("password")) {
            out.println("<html><body>");
            out.println("Welcome Back Admin");
            out.println("</body></html>");
        } else {
            // vulnerable code
            Logger logger = LogManager.getLogger(LoginServlet.class);
            logger.error("Failed login attempt by user: " + userName);

            // Output custom error page with HTML
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"en\">");
            out.println("<head>");
            out.println("    <meta charset=\"UTF-8\">");
            out.println("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            out.println("    <title>Login Failed</title>");
            out.println("    <link href=\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\" rel=\"stylesheet\">");
            out.println("    <style>");
            out.println("        body {");
            out.println("            font-family: 'Poppins', sans-serif;");
            out.println("            margin: 0;");
            out.println("            padding: 0;");
            out.println("            display: flex;");
            out.println("            flex-direction: column;");
            out.println("            justify-content: center;");
            out.println("            align-items: center;");
            out.println("            min-height: 100vh;");
            out.println("            background: linear-gradient(135deg, #ff7e5f, #feb47b);");
            out.println("            position: relative;");
            out.println("        }");
            out.println("        .container {");
            out.println("            background-color: white;");
            out.println("            border-radius: 12px;");
            out.println("            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);");
            out.println("            padding: 40px;");
            out.println("            text-align: center;");
            out.println("            max-width: 400px;");
            out.println("            width: 100%;");
            out.println("        }");
            out.println("        .container img {");
            out.println("            width: 80px;");
            out.println("            height: 80px;");
            out.println("            margin-bottom: 20px;");
            out.println("        }");
            out.println("        .container h1 {");
            out.println("            color: #ff4d4d;");
            out.println("            font-size: 28px;");
            out.println("            margin-bottom: 10px;");
            out.println("        }");
            out.println("        .container p {");
            out.println("            color: #666;");
            out.println("            font-size: 16px;");
            out.println("            margin-bottom: 30px;");
            out.println("        }");
            out.println("        .container p strong {");
            out.println("            font-weight: bold;");
            out.println("        }");
            out.println("        .small-text {");
            out.println("            font-size: 12px;");
            out.println("            color: #999;");
            out.println("            margin-top: 20px;");
            out.println("        }");
            out.println("        .footer-text {");
            out.println("            font-size: 10px;");
            out.println("            color: #666;");
            out.println("            position: absolute;");
            out.println("            bottom: 10px;");
            out.println("            left: 50%;");
            out.println("            transform: translateX(-50%);");
            out.println("            text-align: center;");
            out.println("        }");
            out.println("    </style>");
            out.println("</head>");
            out.println("<body>");
            out.println("    <div class=\"container\">");
            out.println("        <img src=\"https://img.icons8.com/ios-filled/100/ff4d4d/error.png\" alt=\"Error icon\" />");
            out.println("        <h1>Login Failed</h1>");
            out.println("        <p>The password you entered was invalid, <strong>we will log your information</strong></p>");
            out.println("    </div>");
            out.println("    <div class=\"footer-text\">Powered by Java. Served with Tomcat</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    public void destroy() {
    }
}
