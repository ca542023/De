<?php

$gradesMessage = '';

if (isset($_COOKIE['user'])) {
    if ($_COOKIE['user'] == 'STUD1') {
        $gradesMessage = 'student1: Good Grades';
    } elseif ($_COOKIE['user'] == 'STUD2') {
        $gradesMessage = 'student2: Good Grades';
    } elseif ($_COOKIE['user'] == 'STUD3') {
        $gradesMessage = 'student3: Good Grades';
    } elseif ($_COOKIE['user'] == 'THEADMINCOOKIE44301') {
        $gradesMessage = file_get_contents('flags/flag.txt');
    } else {
        die('too bad :(');
    }



} else {
    $gradesMessage = 'No valid user detected.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results | Exam Test Platform</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: DarkGray;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .results-container {
            background-color: #fff;
            padding: 48px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            width: 480px;
        }
        .results-container h1 {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 24px;
        }
        .results-container .grades {
            font-size: 21.6px;
            color: #333;
            margin-bottom: 24px;
        }
        .results-container button {
            width: 100%;
            padding: 12px;
            background-color: #5cb85c;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 19.2px;
            cursor: pointer;
        }
        .results-container button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="results-container">
        <h1>Exam Test Platform</h1>
        <div class="grades">
            <?php echo $gradesMessage; ?>
        </div>
        <form action="/index.php" method="get">
            <button type="submit">Log Out</button>
        </form>

        <?php 
        if (isset($_COOKIE['user'])) {
            echo '<!--for admins, Q29va2llOiB1c2VyPVRIRUFETUlOQ09PS0lFNDQzMDEK-->';
        }
        ?>
    </div>
</body>
</html>
