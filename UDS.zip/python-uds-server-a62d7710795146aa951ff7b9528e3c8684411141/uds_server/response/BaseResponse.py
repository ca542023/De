from abc import abstractmethod, ABC
from ..models.CommonResponseCodes import CommonResponseCodes


class BaseResponse(ABC):

    def __init__(self, service_id: int, common_response_code: CommonResponseCodes = CommonResponseCodes.POSITIVE):
        self.service_id = service_id
        self.common_response_code = common_response_code

    @property
    def service_id(self):
        return self._service_id

    @service_id.setter
    def service_id(self, value):
        self._service_id = value

    @property
    def common_response_code(self):
        return self._common_response_code

    @common_response_code.setter
    def common_response_code(self, value):
        self._common_response_code = value

    @abstractmethod
    def encode(self) -> bytes:
        pass
