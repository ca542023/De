import BaseComponent from '../../baseComponent';
import DragScroll from './helpers/drag-scroll.helper';

const TAB_NAVIGATION_TAB = '.a-tab-navigation__tab';
const TAB_LINKS_SCROLL_LEFT_CLASS = 'a-tab-navigation--scrollLeft';
const TAB_LINKS_SCROLL_RIGHT_CLASS = 'a-tab-navigation--scrollRight';
const TAB_SELECTED_CLASS = `-selected`;
const TAB_DISABLED_CLASS = `-disabled`;

function isButton(element: HTMLElement) {
  return element instanceof HTMLButtonElement;
}
export default class TabNavigation extends BaseComponent {
  protected static events = ['selected'];

  private readonly tabNavigations: HTMLElement;
  private readonly tabs: NodeList;
  private updateTimeout: NodeJS.Timeout;
  private scrollLeft: number;
  private scrollRight: number;
  private wrapper: HTMLElement;
  private dragScroll: DragScroll;

  constructor(container: HTMLElement) {
    super(container);

    this.updateTimeout = null;
    this.scrollLeft = 0;
    this.scrollRight = 0;

    this.dragScroll = new DragScroll(container);

    /**
     * Define DOM Elements and Variables
     */
    this.wrapper = container.parentElement;
    this.tabs = container.querySelectorAll(TAB_NAVIGATION_TAB);
    this.tabNavigations = container;

    Array.from(this.tabs).forEach((tab) => {
      if (tab instanceof HTMLElement) {
        tab.addEventListener('click', () => {
          /**
           * Due to the drag-mechanic of the tabNavigation, we need to prevent
           * clicks on the tabs while the use is dragging the tabNavigation.
           */
          if (this.dragScroll.isClickPrevented()) {
            this.dragScroll.allowClickEvents();
            return;
          }

          if (
            !tab.classList.contains(TAB_SELECTED_CLASS) &&
            !tab.classList.contains(TAB_DISABLED_CLASS)
          ) {
            this.deselectAllTabs();
            tab.classList.add(TAB_SELECTED_CLASS);
            tab.setAttribute(
              isButton(tab) ? 'aria-pressed' : 'aria-selected',
              'true',
            );
            this.triggerEvent('selected', tab.dataset.frokTabIdentifier);
          }
        });
      }
    });

    this.registerScrollUpdates();
  }

  private deselectAllTabs(): void {
    Array.from(this.tabs).forEach((tab) => {
      if (tab instanceof HTMLElement) {
        tab.classList.remove(TAB_SELECTED_CLASS);
        tab.removeAttribute(isButton(tab) ? 'aria-pressed' : 'aria-selected');
      }
    });
  }

  private registerScrollUpdates(): void {
    this.updateTimeout = null;
    const update = () => {
      if (!this.updateTimeout) {
        this.updateTimeout = setTimeout(
          () => this.updateScrollingInformation(),
          250,
        );
      }
    };

    update();
    window.addEventListener('resize', update);
    this.tabNavigations.addEventListener('scroll', update);
  }

  private updateScrollingInformation(): void {
    clearTimeout(this.updateTimeout);

    this.scrollLeft = this.tabNavigations.scrollLeft;
    this.scrollRight =
      this.tabNavigations.scrollWidth -
      this.tabNavigations.offsetWidth -
      this.scrollLeft;
    this.toggleScrollingClass();
  }

  private toggleScrollingClass() {
    this.updateTimeout = null;

    if (!this.wrapper) {
      return;
    }

    this.wrapper.classList.toggle(
      TAB_LINKS_SCROLL_LEFT_CLASS,
      this.scrollLeft > 1,
    );

    this.wrapper.classList.toggle(
      TAB_LINKS_SCROLL_RIGHT_CLASS,
      this.scrollRight > 1,
    );
  }
}
