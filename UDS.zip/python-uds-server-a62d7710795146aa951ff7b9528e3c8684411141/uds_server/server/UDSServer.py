import time

from udsoncan.connections import BaseConnection
import threading

from ..models import SecurityAccessState
from ..models import (
    SecurityLevel,
    Session,
    Context,
    CommonResponseCodes,
    DataItem,
    Memory,
    AddressLength,
    BaseSecurityCryptoProvider,
)
from ..services import BaseServiceInterface
from ..request import BaseRequest
from ..response import NegativeResponse, PositiveResponse


class UDSServer:
    # First entry in sessions and security_levels are default session resp. default security_level
    def __init__(
        self,
        conn: BaseConnection,
        sessions: set[Session],
        services: set[BaseServiceInterface],
        security_levels_unlock: dict[SecurityLevel, BaseSecurityCryptoProvider],
        data_items: set[DataItem],
        session_reset_time: int = 10,
        security_access_blocked_time: int = 10,
        memory: Memory = None,
    ):
        self._connection = conn
        self._services = services
        self._security_levels_unlock = security_levels_unlock
        self._session_reset_time = session_reset_time
        self._session_remaining_reset_time = session_reset_time
        self._security_access_blocked_time = security_access_blocked_time
        self._default_session = None
        for session in sessions:
            if session.is_default_session:
                self._default_session = session
                break
        if not self._default_session:
            raise ValueError("No default session specified.")

        for security_level in security_levels_unlock.keys():
            if security_level.security_level_requestSeed_id % 2 != 1:
                raise ValueError("Security level id must be uneven.")

        if not memory:
            memory = Memory(AddressLength.bit_32)
            memory.add_frame(1024 * 1024, 0x00000000, True)
        self._context = Context(
            self._default_session, sessions, data_items, memory, security_levels_unlock
        )

        # Session Diagnostic timer thread to reset to default session after expiring
        self._session_diag_timer_cond = threading.Condition()
        session_diag_timer_thread = threading.Thread(target=self.session_reset_timer)
        session_diag_timer_thread.daemon = True
        session_diag_timer_thread.start()

        self._security_access_blocked_timer_cond = threading.Condition()
        self._security_access_blocked_timer_thread = threading.Thread(
            target=self.security_access_blocked_timer
        )
        self._security_access_blocked_timer_thread.daemon = True
        self._security_access_blocked_timer_thread.start()

    def start(self) -> bool:
        if not self._connection.is_open():
            self._connection.open()

        while True:
            req = self._get_request()

            # check if requested service is supported by server
            matched_service = None
            for service in self._services:
                if service.id == req.service_id:
                    matched_service = service
                    break

            self._connection.empty_rxqueue()
            # if not supported service
            if not matched_service:
                self._connection.send(
                    NegativeResponse(
                        req.service_id, CommonResponseCodes.SERVICE_NOT_SUPPORTED
                    ).encode()
                )
                continue

            if (
                not matched_service.security_level_whitelist
                or self._context.current_security_level
                in matched_service.security_level_whitelist
            ):
                if (
                    not matched_service.session_whitelist
                    or self._context.active_session in service.session_whitelist
                ):
                    context, resp = matched_service.run(self._context, req.body)
                    # Update context
                    self._context = context

                    # Check if security_access is blocked and start timer
                    if (
                        self._context.current_security_access_state
                        == SecurityAccessState.BLOCKED
                    ):
                        with self._security_access_blocked_timer_cond:
                            self._security_access_blocked_timer_cond.notify()

                    if self._context.active_session != self._default_session:
                        # Reset diagnostic session timer on non-default session
                        self._session_remaining_reset_time = self._session_reset_time
                        with self._session_diag_timer_cond:
                            self._session_diag_timer_cond.notify()
                    if not (
                        isinstance(resp, PositiveResponse)
                        and matched_service.is_suppress_positive_resp_bit()
                    ):
                        self._connection.send(resp.encode())

                else:
                    self._connection.send(
                        NegativeResponse(
                            req.service_id,
                            CommonResponseCodes.SERVICE_NOT_SUPPORTED_IN_ACTIVE_SESSION,
                        ).encode()
                    )
                    continue
            else:
                self._connection.send(
                    NegativeResponse(
                        req.service_id, CommonResponseCodes.SECURITY_ACCESS_DENIED
                    ).encode()
                )
                continue

    def session_reset_timer(self):
        while True:
            while self._session_remaining_reset_time > 0:
                time.sleep(1)
                self._session_remaining_reset_time -= 1

            self._context.active_session = self._default_session
            self._context.reset_security_level()

            # Once the timer expires and resets to default session, wait until session changed to non-default again
            # instead of hammering self._context.current_* vars with default values.
            with self._session_diag_timer_cond:
                self._session_diag_timer_cond.wait()
        # Do some more default session dependend cleanup For example, any configured periodic scheduler or output
        # control shall be disabled and the states of the CommunicationControl and ControlDTCSetting services shall
        # be reset, which means that normal communication shall be re-enabled when it was disabled at the point in
        # time the session is switched to the defaultSession. The server shall reset all activated/initiated/changed
        # settings/controls during the activated session. This does not include long term changes programmed into
        # non-volatile memory. (ISO_14229 Figure 7 — Server diagnostic session state diagram)

    def security_access_blocked_timer(self):
        while True:
            with self._security_access_blocked_timer_cond:
                self._security_access_blocked_timer_cond.wait()

            remaining_security_access_blocked_time = self._security_access_blocked_time

            while remaining_security_access_blocked_time > 0:
                time.sleep(1)
                remaining_security_access_blocked_time -= 1

            self._context.unblock_security_access()

    def _get_request(self) -> BaseRequest:
        frame = None
        while not frame:
            frame = self._connection.wait_frame(60)
        return BaseRequest(int.from_bytes(frame[:1], "big"), frame[1:])
