---
path: "/atoms/divider/guide"
type: "intro"
level: "atoms"
title: "divider"
---

Dividers can be used as-is, within a text or as a vertical divider.