---
path: "/atoms/list/guide"
type: "intro"
level: "atoms"
title: "list"
---

List elements support three styles: dotted, numbered, and checked. The numbered style should only be used for ordered lists.