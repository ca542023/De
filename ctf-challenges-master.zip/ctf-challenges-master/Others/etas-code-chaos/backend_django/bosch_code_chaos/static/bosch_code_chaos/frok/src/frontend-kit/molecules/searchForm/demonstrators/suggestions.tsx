import * as React from 'react';
import { SearchForm } from '../searchForm';

const SearchAutoSuggestionsDemonstrator: React.FunctionComponent = () => (
  <div className="frontend-kit-example_m-search-form">
    <SearchForm />
  </div>
);

export default SearchAutoSuggestionsDemonstrator;
