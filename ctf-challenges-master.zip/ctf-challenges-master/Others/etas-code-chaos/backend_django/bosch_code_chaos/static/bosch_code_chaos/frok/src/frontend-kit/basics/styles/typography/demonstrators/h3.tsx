import * as React from "react";

const H3Demonstrator: React.FunctionComponent = () => (
    <h3>Example headline</h3>
    )

export default H3Demonstrator;