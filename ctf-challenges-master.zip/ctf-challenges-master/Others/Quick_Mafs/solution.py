import socket


server_ip = 'localhost'
server_port = 9999


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((server_ip, server_port))

try:
    while True:

        data = s.recv(4096).decode().strip() 

        print(f"Received: {data}")
        
        for line in data.split('\n'):
            line = line.strip()
            if any(op in line for op in ['+', '-', '*', '/']):
                for op in ['+', '-', '*', '/']:
                    if op in line:
                        try:
                            parts = line.split(op)
                            num1 = int(parts[0].strip())
                            num2 = int(parts[1].strip())
                            result = 0
                            
                            if op == '+':
                                result = num1 + num2
                            elif op == '-':
                                result = num1 - num2
                            elif op == '*':
                                result = num1 * num2
                            elif op == '/':
                                result = num1 // num2  
                            break
                        except ValueError:
                            print(f"Invalid data received: {line}, skipping...")
                            continue

                if 'result' in locals():
                    print(f"Sending result: {result}")
                    s.sendall(str(result).encode())
                    del result  
            else:
                print(line)

        if 'ETAS{' in data:
            print(f"Flag received: {data}")
            break

finally:
    s.close()
