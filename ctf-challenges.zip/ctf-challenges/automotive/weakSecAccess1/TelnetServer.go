/*
This challenge implements a weak seed key algorithm. This must be reverse engineered to calculate a valid key for arbitrary seeds. Bruteforcing is not allowed and is blocked.
*/
package main

import (
	"encoding/hex"
	"io"

	// library to add for bonus points. After solving this challenge a bonus question should pop up with this source code provided and one should point out the flaw that this lib is not cryptographical secure
	"math/rand"
	"os"
	"time"

	"github.com/reiver/go-oi"
	"github.com/reiver/go-telnet"
	"github.com/reiver/go-telnet/telsh"
)

var CompareHandlerCallCount = 0
var PROMBT = ">"
var current_seed = ""

func helpTextHandler(stdin io.ReadCloser, stdout io.WriteCloser, stderr io.WriteCloser, args ...string) error {
	oi.LongWriteString(stdout, "\r  Request a seed with getSeed, compute the key and submit with compareKey <key> to unlock the device.\r\n ")
	return nil
}

func helpTextProducer(ctx telnet.Context, name string, args ...string) telsh.Handler {
	return telsh.PromoteHandlerFunc(helpTextHandler)
}

func requestSeedHandler(stdin io.ReadCloser, stdout io.WriteCloser, stderr io.WriteCloser, args ...string) error {
	buf := make([]byte, 8)
	_, err := rand.Read(buf)
	if err != nil {
		oi.LongWriteString(stdout, "error while generating random string: "+err.Error())
	}
	current_seed = hex.EncodeToString(buf)
	oi.LongWriteString(stdout, "\r"+current_seed+"\r\n ")
	return nil
}

func requestSeedProducer(ctx telnet.Context, name string, args ...string) telsh.Handler {

	return telsh.PromoteHandlerFunc(requestSeedHandler)
}

func compareKeyHandler(stdin io.ReadCloser, stdout io.WriteCloser, stderr io.WriteCloser, args ...string) error {

	if CompareHandlerCallCount >= 50 {
		oi.LongWriteString(stdout, "\r Bruteforce attempt detected. Taking a break!\r\n ")
		time.Sleep(10 * time.Second)
		CompareHandlerCallCount = 0
		return nil
	}
	CompareHandlerCallCount++
	if len(args) != 1 {
		oi.LongWriteString(stdout, "\r Argument error...\r\n ")
		return nil
	}

	key := args[0]
	rawSeed, err := hex.DecodeString(current_seed)
	if err != nil {
		oi.LongWriteString(stdout, "\r Error: "+err.Error()+"\r\n ")
		return nil
	}
	derivedKey, err := CreateKeyFromSeed(rawSeed)
	if err != nil {
		oi.LongWriteString(stdout, "\r Error: "+err.Error()+"\r\n ")
		return nil
	}
	if hex.EncodeToString(derivedKey) == key {
		flag := readFlag()
		oi.LongWriteString(stdout, "\r Nice job. Take your reward: "+flag+"\r\n ")
	} else {
		oi.LongWriteString(stdout, "\r Wrong key.\r\n")
	}

	time.Sleep(time.Duration(CompareHandlerCallCount) * 100 * time.Millisecond)
	return nil
}

func comparekeyProducer(ctx telnet.Context, name string, args ...string) telsh.Handler {

	return telsh.PromoteHandlerFunc(compareKeyHandler, args...)
}

func bruteforceProtectionResetter() {
	for {
		time.Sleep(10 * time.Second)
		CompareHandlerCallCount = 0
	}
}

func readFlag() string {

	// Specify the name of the environment variable
	envVarName := "FLAG"

	// Attempt to retrieve the value of the environment variable
	envVarValue, exists := os.LookupEnv(envVarName)

	// Check if the environment variable exists
	if exists {
		return envVarValue
	}

	return ""
}

func main() {

	shellHandler := telsh.NewShellHandler()
	shellHandler.Prompt = PROMBT
	shellHandler.WelcomeMessage = "\r\n" +

		"Welcome to the:\r\n" +
		" ____  ____  ____  ____         _ _            _\r\n" +
		"/ ___||  _ \\/ ___||  _  \\   ___| (_) ___ _ __ | |_\r\n" +
		"\\___ \\| | | \\___ \\| | | |  / __| | |/ _ \\ '_ \\| __|\r\n" +
		" ___) | |_| |___) | |_| | | (__| | |  __/ | | | |_ \r\n" +
		"|____/|____/|____/|____/   \\___|_|_|\\___|_| |_|\\__|\r\n" +

		"\r\nThe super duper secure diagnostic client.\r\nType 'help' to get a list of commands.\r\n\r"
	// Register the "five" command.
	commandName := "help"
	commandProducer := telsh.ProducerFunc(helpTextProducer)
	shellHandler.Register(commandName, commandProducer)

	// Register the "" command.
	commandName = "getSeed"
	commandProducer = telsh.ProducerFunc(requestSeedProducer)

	shellHandler.Register(commandName, commandProducer)

	// Register the "" command.
	commandName = "compareKey"
	commandProducer = telsh.ProducerFunc(comparekeyProducer)

	shellHandler.Register(commandName, commandProducer)

	addr := ":5555"
	go bruteforceProtectionResetter()
	if err := telnet.ListenAndServe(addr, shellHandler); nil != err {
		panic(err)
	}
}
