import BaseComponent from '../../baseComponent';

class ColorInput extends BaseComponent {
  private colorInput: HTMLInputElement;

  constructor(container: HTMLElement) {
    super(container);

    /**
     * Define DOM Elements and Variables
     */
    this.colorInput = this.container.querySelector('input');

    if (this.colorInput) {
      this.colorInput.addEventListener('focus', this.handleFocus.bind(this));
      this.colorInput.addEventListener('blur', this.handleBlur.bind(this));
      this.colorInput.addEventListener('input', this.handleChange.bind(this));
    }
  }

  /**
   * @name handleFocus
   * @description
   * When input receives focus add color to its parent
   */
  private handleFocus(): void {
    this.container.style.backgroundColor =
      'var(--neutral__focused__fill__default)';
  }

  /**
   * @name handleBlur
   * @description
   * When input loses focus remove color to its parent
   */
  private handleBlur(): void {
    this.container.style.backgroundColor = '';
  }

  /**
   * @name handleChange
   * @description
   * Sync the color of the :before element with the input's selection
   */
  private handleChange(event: Event): void {
    const selectedColor = (event.target as HTMLInputElement).value;
    this.container.style.setProperty('--before-color', selectedColor);
  }
}

export default ColorInput;
