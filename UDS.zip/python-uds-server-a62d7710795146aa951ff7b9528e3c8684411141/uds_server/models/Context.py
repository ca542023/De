from .security.SecurityAccessState import SecurityAccessState
from .security.SecurityLevel import SecurityLevel
from .security.DefaultSecurityCryptoProvider import DefaultSecurityCryptoProvider
from .security.BaseSecurityCryptoProvider import BaseSecurityCryptoProvider
from .Memory import Memory
from .DowloadUploadJob import DownloadUploadJob
from .Session import Session
from .DataItem import DataItem


class Context:
    def __init__(
        self,
        active_session: Session,
        sessions: set[Session],
        data_items: set[DataItem],
        memory: Memory,
        security_levels_unlock: dict[SecurityLevel, BaseSecurityCryptoProvider] = None,
    ):
        self.active_session = active_session
        self.current_security_level = None
        self.sessions = sessions
        self.data_items = data_items
        self.current_security_access_state = SecurityAccessState.WAIT_FOR_SEED
        self.current_seed = None
        self.security_access_attempts = 0
        if not security_levels_unlock:
            security_levels_unlock = {1: DefaultSecurityCryptoProvider()}
        else:
            self.security_levels_unlock = security_levels_unlock
        self.memory = memory
        self.download_upload_job = DownloadUploadJob()

    @property
    def download_upload_job(self) -> DownloadUploadJob:
        return self._download_upload_job

    @download_upload_job.setter
    def download_upload_job(self, value: DownloadUploadJob):
        self._download_upload_job = value

    @property
    def memory(self) -> Memory:
        return self._memory

    @memory.setter
    def memory(self, value):
        self._memory = value

    @property
    def security_access_attempts(self) -> int:
        return self._security_access_attempts

    @security_access_attempts.setter
    def security_access_attempts(self, value: int):
        self._security_access_attempts = value

    @property
    def security_levels_unlock(self) -> dict[SecurityLevel, BaseSecurityCryptoProvider]:
        return self._security_levels_unlock

    @security_levels_unlock.setter
    def security_levels_unlock(
        self, value: dict[SecurityLevel, BaseSecurityCryptoProvider]
    ):
        self._security_levels_unlock = value

    @property
    def active_session(self) -> Session:
        return self._current_session

    @active_session.setter
    def active_session(self, value: Session):
        self._current_session = value

    @property
    def sessions(self) -> set[Session]:
        return self._sessions

    @sessions.setter
    def sessions(self, value: set[Session]):
        self._sessions = value

    @property
    def current_security_level(self) -> SecurityLevel:
        return self._current_security_level

    @current_security_level.setter
    def current_security_level(self, value: SecurityLevel):
        self._current_security_level = value

    @property
    def data_items(self) -> set[DataItem]:
        return self._data_items

    @data_items.setter
    def data_items(self, value: set[DataItem]):
        self._data_items = value

    @property
    def current_seed(self) -> bytes:
        return self._current_seed

    @current_seed.setter
    def current_seed(self, value: bytes):
        self._current_seed = value

    def reset_security_level(self):
        if self.current_security_access_state != SecurityAccessState.BLOCKED:
            self.current_security_access_state = SecurityAccessState.WAIT_FOR_SEED
        self.current_seed = None
        self.current_security_level = None

    def unblock_security_access(self):
        self.security_access_attempts = 0
        self.current_security_access_state = SecurityAccessState.WAIT_FOR_SEED

    def find_session(self, session_id: int) -> Session:
        for session in self._sessions:
            if session.session_id == session_id:
                return session

    def find_data_item_by_did(self, did: int) -> DataItem:
        for data_item in self._data_items:
            if data_item.did == did:
                return data_item
