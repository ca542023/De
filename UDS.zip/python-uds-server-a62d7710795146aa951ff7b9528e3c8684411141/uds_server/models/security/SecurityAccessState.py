from enum import Enum, IntEnum


class SecurityAccessState(IntEnum):
    WAIT_FOR_SEED = 0,
    WAIT_FOR_KEY = 1,
    BLOCKED = 99,
