import can, random
from uds_server.models import (
    Session,
    SecurityLevel,
    DataItem,
    Context,
    BaseSecurityCryptoProvider,
    DefaultSecurityCryptoProvider,
)
from uds_server.services import (
    BaseServiceInterface,
    DiagnosticSessionControlService,
    TesterPresentService,
    ReadDataByIdentifierService,
    SecurityAccessService,
)
from udsoncan.connections import PythonIsoTpConnection
import isotp
from can.interfaces.socketcan import SocketcanBus
from uds_server import UDSServer

isotp_params = {
    "stmin": 32,
    # Will request the sender to wait 32ms between consecutive frame. 0-127ms or 100-900ns with values from 0xF1-0xF9
    "blocksize": 0,  # Request the sender to send 8 consecutives frames before sending a new flow control message
    "wftmax": 0,  # Number of wait frame allowed before triggering an error
    "tx_data_length": 8,  # Link layer (CAN layer) works with 8 byte payload (CAN 2.0)
    "tx_data_min_length": None,
    # Minimum length of CAN messages. When different from None, messages are padded to meet this length. Works with CAN 2.0 and CAN FD.
    "tx_padding": 0,  # Will pad all transmitted CAN messages with byte 0x00.
    "rx_flowcontrol_timeout": 2000,  # Triggers a timeout if a flow control is awaited for more than 1000 milliseconds
    "rx_consecutive_frame_timeout": 1000,
    # Triggers a timeout if a consecutive frame is awaited for more than 1000 milliseconds
    "squash_stmin_requirement": False,
    # When sending, respect the stmin requirement of the receiver. If set to True, go as fast as possible.
    "max_frame_size": 4095,  # Limit the size of receive frame.
    "listen_mode": False,
}


def main():
    bus = SocketcanBus(channel="vcan0")
    tp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits, 0x102, 0x101)
    stack = isotp.CanStack(bus=bus, address=tp_addr, params=isotp_params)
    conn = PythonIsoTpConnection(stack)
    # Define Sessions
    default_session = Session(0x01, "default_session", is_default_session=True)
    programming_session = Session(0x02, "programming_session")
    sessions = set[Session]([default_session, programming_session])

    # Define the servers allowed Session transistions
    default_session_transition = (
        default_session,
        {default_session, programming_session},
    )
    programming_session_transition = (
        programming_session,
        {default_session, programming_session},
    )
    session_transitions = dict(
        [default_session_transition, programming_session_transition]
    )

    # Define Services
    services = set[BaseServiceInterface](
        [
            DiagnosticSessionControlService(session_transitions=session_transitions),
            TesterPresentService(),
            ReadDataByIdentifierService(),
            SecurityAccessService(),
        ]
    )

    # define Security Levels
    security_levels = {
        SecurityLevel(1): CH1CryptoProvider(key=b"\x83\x44\xef\x6a\xee\x48\xc4\x8f"),
        SecurityLevel(3): DefaultSecurityCryptoProvider,
    }
    data_items = {
        DataItem(0xF186, "Get current Session", 0x1234, get_active_session),
        DataItem(0xF282, "Get all supported Sessions", 0x4321, supported_sessions),
        DataItem(0x0102, "Hello World!", 0x0102, b"Hello, World!"),
        DataItem(
            0x0010,
            "DIDs",
            0x0010,
            b"Get all sessions: f282\n get current session f186\n ??? 00fe",
        ),
        DataItem(
            0x00FE,
            "Secret",
            0xFFFF,
            b"flag{DEMOFLAG_CHANGE_PLS}",
            {programming_session},
        ),
    }

    # Initialize UDS Server with predefined parts
    uds_server = UDSServer(conn, sessions, services, security_levels, data_items)
    uds_server.start()


def get_active_session(context: Context) -> bytes:
    return context.active_session.encode()


# noinspection PyUnusedLocal
def supported_sessions(context: Context) -> bytes:
    sessions_output = []
    for session in context.sessions:
        sessions_output.append(session.session_id)

    return b"".join(i.to_bytes(1, "big") for i in sessions_output)


class CH1CryptoProvider(BaseSecurityCryptoProvider):
    def __init__(self, key: bytes):
        random.seed(0xAF, 1)
        super().__init__(key)

    def generate_seed(self, associated_data=None):
        return random.randbytes(8)

    def generate_key(self, seed: bytes):
        return int.from_bytes(seed, "big") ^ int.from_bytes(self._key, "big")


if __name__ == "__main__":
    main()
