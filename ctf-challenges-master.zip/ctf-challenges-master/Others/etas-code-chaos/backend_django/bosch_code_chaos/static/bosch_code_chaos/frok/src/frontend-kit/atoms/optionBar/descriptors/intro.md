---
path: "/atoms/optionBar/guide"
type: "intro"
level: "atoms"
title: "option bar"
---

Option bars are a different visual representation of a radio group.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
    For this component to work correctly, you will need to set the <code>name</code> attribute of all the <code>input</code> elements in the same bar to the same value, and
    also give proper <code>id</code> attributes that match the respective <code>for</code> attributes on the labels.
</div></div>
