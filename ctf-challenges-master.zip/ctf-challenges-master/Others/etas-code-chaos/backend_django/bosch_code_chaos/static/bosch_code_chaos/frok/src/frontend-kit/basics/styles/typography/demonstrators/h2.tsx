import * as React from "react";

const H2Demonstrator: React.FunctionComponent = () => (
    <h2>Example headline</h2>
    )

export default H2Demonstrator;