import pytest
from uds_server.models import SecurityLevel


@pytest.fixture
def default_security_level_3():
    return SecurityLevel(security_level_requestSeed_id=0x03)


def test_security_level_request_seed_id_get(default_security_level_3):
    request_seed_id = default_security_level_3.security_level_requestSeed_id
    assert request_seed_id == 0x03


def test_security_level_request_seed_id_set(default_security_level_3):
    default_security_level_3.security_level_requestSeed_id = 0x99
    request_seed_id = default_security_level_3.security_level_requestSeed_id
    assert request_seed_id == 0x99


def test_security_level_send_key_id(default_security_level_3):
    sendKey_id = default_security_level_3.security_level_sendKey_id
    assert sendKey_id == 0x04


def test_encode(default_security_level_3):
    seed, key = default_security_level_3.encode()
    assert seed+key == b'\x03\x04'
