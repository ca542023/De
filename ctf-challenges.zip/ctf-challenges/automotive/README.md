Automotive CTF Challenges
-------------------------

The automotive challenges for N participants are implemented using N pairs of
docker containers - one pair per participant.
One docker container pair consists of:
  - a container running the challenges
  - a container running an SSH server to which the participants can connect

The two containers communicate using a peer-to-peer network link of type
`vxcan`. The two network endpoints are moved into the respective network
namespaces of the container pairs.

The challenge setup is managed by ansible using the playbook
`playbook.ansible.yml`.

Install the required software on the host machine (e.g. using `apt`):
  - `apt install git python3 python3-venv docker.io`

Get the code for the `python-uds-server`:
  - `git submodule update --init --recursive`

Configure the playbook:
  - copy the default configuration `ansible_conf.default.yml` to
  `ansible_conf.yml` and make your local changes there. This file will be
  excluded from version control by `.gitignore`.

Run the playbook:
  - `./run_ansible.sh -c ansible_conf.yml playbook.ansible.yml`

Restart the containers of the playbook:
  - `./run_ansible.sh -c ansible_conf.yml -r playbook.ansible.yml`

Stop the playbook:
  - `./run_ansible.sh -c ansible_conf.yml -s playbook.ansible.yml`

Get the passwords of the participants of the respective SSH server containers:
  - `./receive_cnt_infos.sh`


Caution
-------
Note that the entrypoint commands executed in the docker containers might
silently fail! Since the docker containers created by the ansible playbook are
not one-shot but long running services, they have to be detached from the
playbook, thus making it not feasible to verify the exit code of their
entrypoint commands. Registering a [healthcheck](https://docs.ansible.com/ansible/latest/collections/community/docker/docker_container_module.html#parameter-healthcheck)
is also not quite suitable for dealing with the problem in this context.
As a result you need to check the `docker logs` manually in case something
went wrong.
