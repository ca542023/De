
# CTF Workshop Service

The current version of the repository contains all auto-buildable challenges and a customized version of the CTF management platform [CTFd](/CTFd). Unrefactored challenges, that are currently not integrated in the docker/ansible build pipeline can be found [in the SVN](https://etassvn.de.bosch.com/!/#escrypt.CTF.Security.Workshop/view/head/Challenges). Currently only the automotive challenges are to be considered refactored.

# Install

## CTFd
> See [here](CTFd/README.md)

## Automotive
Run `./automotive/docker/build_container.sh && ./automotive/services/setup.sh -n 10 -i` to install and setup 10 docker containers.
>See [here](/automotive/README.md)

## Others
> Currently all docker images and static VMs are getting integrated in the build pipeline with ansible. Docker images should be replaced by a Dockerfile that uses an base image to avoid large files on GitHub.

Please refer to the [SVN](https://etassvn.de.bosch.com/!/#escrypt.CTF.Security.Workshop/view/head/Challenges) to setup non-refactored challenges.