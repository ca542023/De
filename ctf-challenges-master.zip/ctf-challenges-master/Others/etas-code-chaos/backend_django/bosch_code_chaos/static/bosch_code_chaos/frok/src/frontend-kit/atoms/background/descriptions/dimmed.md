---
path: "/atoms/background/guide"
type: "variant"
level: "atoms"
title: "background"
variant: "dimmed"
---

Use the dimmed background below some content to make it easier to focus visually. See [Modal Box](/atoms/box/guide) for a usage example.
