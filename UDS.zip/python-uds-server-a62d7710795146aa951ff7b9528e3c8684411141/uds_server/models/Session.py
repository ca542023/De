from .security.SecurityLevel import SecurityLevel


class Session:
    def __init__(
        self,
        session_id: int,
        session_description: str,
        security_level_whitelist: tuple[SecurityLevel] = None,
        is_default_session: bool = False,
    ):
        self.session_id = session_id
        self.session_description = session_description
        self.security_level_whitelist = security_level_whitelist
        self.is_default_session = is_default_session

    @property
    def session_id(self) -> int:
        return self._session_id

    @session_id.setter
    def session_id(self, value: int):
        self._session_id = value

    @property
    def session_description(self) -> str:
        return self._session_description

    @session_description.setter
    def session_description(self, value: str):
        self._session_description = value

    @property
    def security_level_whitelist(self) -> tuple[SecurityLevel]:
        return self._security_level_whitelist

    @security_level_whitelist.setter
    def security_level_whitelist(self, value: tuple[SecurityLevel]):
        self._security_level_whitelist = value

    @property
    def is_default_session(self) -> bool:
        return self._is_default_session

    @is_default_session.setter
    def is_default_session(self, value: bool):
        self._is_default_session = value

    def encode(self) -> bytes:
        return self._session_id.to_bytes(1, "big")
