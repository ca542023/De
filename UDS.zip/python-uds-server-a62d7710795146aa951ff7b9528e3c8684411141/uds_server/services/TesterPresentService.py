from types import FunctionType
from ..models import CommonResponseCodes, Context
from ..response import NegativeResponse, BaseResponse, PositiveResponse
from ..services.BaseService import BaseServiceInterface


class TesterPresentService(BaseServiceInterface):

    def __init__(self, requestSID: int = 0x3e, subfunctions: dict[int, FunctionType] = None):
        # Service is available in every session and by every security level
        # noinspection PyTypeChecker
        super().__init__(requestSID, None, None)
        self._subfunctions: dict[int, FunctionType] = subfunctions

    def run(self, context: Context, sub_fun_data: bytes) -> tuple[Context, BaseResponse]:
        if len(sub_fun_data) > 1:
            return context, NegativeResponse(self.id,
                                             CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT)

        sub_fun_identifier = int.from_bytes(sub_fun_data, 'big')
        self.set_suppress_positive_resp_bit(sub_fun_identifier)

        if self._subfunctions and sub_fun_identifier != 0:
            if sub_fun_identifier in self._subfunctions:
                associated_data = self._subfunctions.get(sub_fun_identifier)()
                return context, PositiveResponse(self.id, associated_data)

        return context, PositiveResponse(self.id, sub_fun_data)
        # Check suppress positive response bit
