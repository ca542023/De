from django.conf import settings

def etas_branding(request):
    return {'ETAS_BRANDING': settings.ETAS_BRANDING}