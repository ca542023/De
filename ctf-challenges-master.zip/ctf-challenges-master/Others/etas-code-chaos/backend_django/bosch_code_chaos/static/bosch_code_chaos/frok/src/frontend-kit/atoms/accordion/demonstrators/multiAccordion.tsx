import * as React from 'react';
import { Accordion } from '../accordion';

interface MultiAccordionProps {
  size?: 'small' | 'large';
  name?;
}

const MultiAccordionDemonstrator: React.FunctionComponent<MultiAccordionProps> =
  ({ size = 'large', name }) => {
    return (
      <>
        <Accordion
          size={size}
          headline="Accordion Headline 1"
          name={`${name} 1`}
        />
        <Accordion
          size={size}
          headline="Accordion Headline 2"
          name={`${name} 2`}
        />
        <Accordion
          size={size}
          headline="Accordion Headline 3"
          name={`${name} 3`}
        />
        <Accordion
          size={size}
          headline="Accordion Headline 4"
          name={`${name} 4`}
        />
      </>
    );
  };

export default MultiAccordionDemonstrator;
