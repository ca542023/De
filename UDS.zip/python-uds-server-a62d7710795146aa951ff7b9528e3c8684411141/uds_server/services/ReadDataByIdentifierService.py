from ..models import Session, SecurityLevel, DataItem, Context, CommonResponseCodes
from ..response import BaseResponse, NegativeResponse, PositiveResponse
from ..services.BaseService import BaseServiceInterface


def _resolve_did_data(did: DataItem, context: Context):
    if type(did.data) is bytes:
        return did.data
    elif callable(did.data):
        return did.data(context)


class ReadDataByIdentifierService(BaseServiceInterface):
    def __init__(
        self,
        requestSID: int = 0x22,
        session_whitelist: set[Session] = None,
        security_level_whitelist: tuple[SecurityLevel] = None,
    ):
        # Service is available in every session and by every security level
        super().__init__(requestSID, session_whitelist, security_level_whitelist)

    def run(
        self, context: Context, sub_fun_data: bytes
    ) -> tuple[Context, BaseResponse]:
        # Check if did exists
        if len(sub_fun_data) % 2 != 0:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT
            )

        requested_dids: list[bytes] = list()
        for i in range(0, len(sub_fun_data), 2):
            requested_dids.append(sub_fun_data[i : i + 2])

        accessible_dids: list[DataItem] = list()
        for requested_did in requested_dids:
            data_id = int.from_bytes(requested_did, "big")
            matched_data_item = context.find_data_item_by_did(data_id)

            if not matched_data_item:
                continue

            # if not allowed in current session
            if (
                matched_data_item.session_whitelist
                and context.active_session not in matched_data_item.session_whitelist
            ):
                continue

            if (
                matched_data_item.security_level_whitelist
                and context.current_security_level
                not in matched_data_item.security_level_whitelist
            ):
                return context, NegativeResponse(
                    self.id, CommonResponseCodes.SECURITY_ACCESS_DENIED
                )

            # TODO: implement condition check? Each condition as function with bool return handed over from caller.
            #  Evaluate function if one of them returned false send NRC 22
            accessible_dids.append(matched_data_item)

        if len(accessible_dids) == 0:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUEST_OUT_OF_RANGE
            )
        return context, PositiveResponse(
            self.id,
            b"".join(
                [
                    x.did.to_bytes(2, "big") + _resolve_did_data(x, context)
                    for x in accessible_dids
                ]
            ),
        )
