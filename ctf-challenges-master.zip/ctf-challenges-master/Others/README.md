# Getting Started

1. activate virtual environment:\
`python3 -m venv ansible_env source ansible_env/bin/activate`

2. install ansible (by firsttime running):\
`pip install ansible docker`

# Commands
## BUILD
`ansible-playbook ansible_playbook.yml --tags start --ask-become-pass`\
build images + start container

## STOP
`ansible-playbook ansible_playbook.yml --tags clean --ask-become-pass`\
stop container + remove images, docker

## RESTART
`ansible-playbook ansible_playbook.yml --tags restart --ask-become-pass`\
stop container + remove images, docker + build images + start container

## Misc
```
ansible-playbook ansible_playbook.yml --tags build_images --ask-become-pass
ansible-playbook ansible_playbook.yml --tags start_container --ask-become-pass
ansible-playbook ansible_playbook.yml --tags stop_container --ask-become-pass
ansible-playbook ansible_playbook.yml --tags restart_container --ask-become-pass
```