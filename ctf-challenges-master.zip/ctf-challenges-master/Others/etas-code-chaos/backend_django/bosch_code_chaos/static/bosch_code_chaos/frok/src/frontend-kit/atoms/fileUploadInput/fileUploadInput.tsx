/* eslint-disable import/prefer-default-export */
import * as React from 'react';
import classNames from 'classnames';
import { Icon } from '../icon/icon';

interface FileUploadInputProps {
  label: string;
  id: number;
  name: string;
  isDisabled?: boolean;
}

/**
 * @name      a-file-upload-input
 * @type      atom
 * @author    Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @param   {string} label             Label to Display
 * @param   {string} id                Unique ID for each file upload input
 * @param   {string} name              Unique name attribute for each file upload input
 * @param   {boolean} isDisabled       Wether or not the file upload input is disabled
 *
 * @description
 * representation of file upload input
 */

const FileUploadInput: React.FunctionComponent<FileUploadInputProps> = ({
  label,
  id,
  name,
  isDisabled,
}) => {
  const idFileUploadInput = `file-upload-input-${id}`;

  const fileUploadInputClass = classNames('a-file-upload-input', {
    'a-file-upload-input--disabled': isDisabled,
  });

  return (
    <div className={fileUploadInputClass}>
      <label htmlFor={idFileUploadInput}>
        <Icon iconName="upload" titleText="upload icon" />
        {label}
      </label>
      <input
        id={idFileUploadInput}
        name={name}
        type="file"
        disabled={isDisabled}
      />
      <div className="a-file-upload-input__preview">
        <p>No file chosen</p>
      </div>
    </div>
  );
};

export { FileUploadInput };
