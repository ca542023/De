import * as React from "react";

const PDemonstrator: React.FunctionComponent = () => (
    <p>Example paragraph</p>
    )

export default PDemonstrator;