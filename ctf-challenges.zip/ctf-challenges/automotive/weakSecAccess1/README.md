# Setup
- Should be automatically started by ansible
- **Create challenge description and link the SeedKey binary from this repo in CTFd**

## Description template
We have developed a remote diagnostic service, that helps the car manufacturer to access important diagnostic information from a vehicle in field. Unfortunately the budget is very limited so right now it supports just the *SecurityAccess*. BUT we use state-of-the-art security here!
<br>
Request a seed and send it along the key to the service. If the computed key matches with the one send to the service you get free access to the vehicle.
<br>Just try it out! You find an interface on port 5555.

# Solution

1. Reverse the provided SeedKey binary. 
2. Identify the function that derives the key.
3. The function rotates the seed in a certain pattern (see SeedKey.go).
4. After the rotation the seed is XORed with a static IV.
5. This info can be used to request a seed and compute the key.
6. Sending the key with `compareKey <derivedKey>` should reveal the flag.

