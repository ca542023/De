# CTFd
[CTFd](https://github.com/CTFd/CTFd) is a Capture The Flag framework focusing on ease of use and customizability. It comes with everything you need to run a CTF and it's easy to customize with plugins and themes.

# Install
The esasiest way is to use docker:

```console
docker run -p 8000:8000 -it ctfd/ctfd
```

or from the sources with 
```console
git clone https://github.com/CTFd/CTFd.git
cd CTFd/
docker compose up
```

# Setup
We have created an **ETAS** branded CTFd instance. In order to install it, get the current master template with:
```console
git clone https://github.boschdevcloud.com/ETAS-SEC-Penetration-Testing/ctf-challenges.git
```
>Info: If you just need CTFd use sparce checkout to avoid pulling the entiere repo. see [here](#sparce-checkout) or manually download the [latest CTFd ETAS template](master/CTFD_ETAS_TEMPLATE.zip). 

In `CTFd/master` you can find the newest config. \
In `CTFd/history` you can find configs from past events. \
Default login is `admin:wA1NLvNptr`
## Import
1. Go to `localhost:8000`
2. Go to `Admin Panel` -> `Config` -> `Backup` -> `Import`
3. Select the master or other CTFd exports in this repo. (Ending on .zip)
4. Click `Import`
5. (Optional) Go to `Admin Panel` -> `Config` -> `Reset`
6. (Optional) Select `Accounts`, `Submission` and click `Reset`
> Reset is recommend cause after one get presented with a guided interactive tutorial to easily set up all important informations like admin login, CTF name, starting times etc. The design, images, pages and challenges are still present. 

# Customization
We've made multiple post-install modifcation to e.g. implement a dynamic scoreboard with interactive solve notifications or set the automotive ssh credentials via a custom field in the user profile. This section describes the setup.
## Plugins
Install notifyer server with `mv notifyer CTFd/CTFd-<version-number>/plugins`. This custom plugin offers a websocket endpoint that sends data on solve. This data is displayed by a custom CTFd site that is included in the current master template.
## Config
This script automatically sets the ssh credentials to access the automotive challenges in the users profile via a custom field. Each participant has his own docker instance he can access via these credentials.
> First create the automotive challenge containers see [here](../automotive/README.md)
1. Open `config.py` and set
```python
ctfd_host = "http://localhost:8000/api/v1/"
docker_host_ip = "EXTERNAL_IP" # The ip where the automotive challenges are accessible for the participants
token = "ctfd_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"  # CTFd API TOKEN
```
2. `python config.py`

## Custom Variables
> This is a very hacky solution and we should check for alternatives

We customized CTFd to store some variables to avoid re-writing IP addresses in every challenges when the network changes. These variables are stored in `~/Documents/CTFd/CTFd-<version-number>/CTFd/utils/config/pages.py:Line 33`.\

    automotive_ip:<ip> # IP address of automotive challenge docker host
    win7_ip:<ip> 
    general_ip:<ip> # IP address of docker host for non-automotive challenges

## Update CTFd Version (Optional)
1. Create backup of CTFd config
    - Go to `localhost:8000`
    - Go to `Admin Panel` -> `Config` -> `Backup` -> `Import`
2. Save plugin 'notifyer' in ctfd/ctfd/plugins
    ```
    cp -r "CTFd/CTFd-<version-number>/plugins/notifyer /tmp/notifyer_bak
    ```
3. All files in "~/Documents/CTFd/CTFd-<version-number>/conf/*"
4. Pages.py (See previous section: [Variables](#custom-variables))


## Sparce checkout
```console
function git_sparse_clone() (
  rurl="$1" localdir="$2" && shift 2

  mkdir -p "$localdir"
  cd "$localdir"

  git init
  git remote add -f origin "$rurl"

  git config core.sparseCheckout true

  # Loops over remaining args
  for i; do
    echo "$i" >> .git/info/sparse-checkout
  done

  git pull origin master
)
```
Usage
```console
git_sparse_clone "http://github.com/tj/n" "./local/location" "/bin"
```



