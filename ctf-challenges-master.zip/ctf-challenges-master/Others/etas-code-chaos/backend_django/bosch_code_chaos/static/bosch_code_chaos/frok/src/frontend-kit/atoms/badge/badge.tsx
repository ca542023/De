import classNames from 'classnames';
import * as React from 'react';

interface BadgeProps {
  label: string;
  type?: 'success' | 'warning' | 'error';
}

/**
 * @name    a-badge
 * @type    atom
 * @author Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @param   {string} type                 Type of badge (neutral, success, warning, error)
 * @param   {string} label                Label to Display
 *
 * @description
 * representation of badges
 */

const Badge: React.FunctionComponent<BadgeProps> = ({ label, type }) => {
  const badgeClass = classNames('a-badge', {
    [`-${type}`]: type,
  });

  return (
    // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
    <div className={badgeClass} tabIndex={0} role="status" aria-live="off">
      {label}
    </div>
  );
};

export { Badge };
export type { BadgeProps };
