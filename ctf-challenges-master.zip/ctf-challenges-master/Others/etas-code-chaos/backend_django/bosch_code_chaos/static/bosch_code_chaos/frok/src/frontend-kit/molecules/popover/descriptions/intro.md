---
path: "/molecules/popover/guide"
type: "intro"
level: "molecules"
title: "popover"
---

A popover is a larger variant of the tooltip. It can optionally have a button, a close button, or a headline, and one of 12 arrow positions.

The popover component has a JS API to attach the popover to any element. The arrow position determines the popover position, so be careful to not place it off-screen. See the gallery example and the API description below for details.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
    For accessibility reasons, a keyboard trap is highly recommended in this component.
    However, to prevent some unpredictable side effects (the page freezing, the user is stuck in an infinite loop, etc.), the keyboard trap was not set for this page to work correctly. Therefore it needs to be set by the developer.
</div></div>
