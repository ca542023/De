import * as React from "react";

const H4Demonstrator: React.FunctionComponent = () => (
    <h4>Example headline</h4>
    )

export default H4Demonstrator;