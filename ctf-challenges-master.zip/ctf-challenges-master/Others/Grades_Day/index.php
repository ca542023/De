<?php
setcookie('user', '', time() + (86400 * 30));
if(isset($_POST['username']) && isset($_POST['password']))
{
    $u = $_POST['username'];
    $p = $_POST['password'];

    if(($u === 'student1') && ($p === 'password1'))
    {
        setcookie('user', 'STUD1', time() + (86400 * 30), "/");
        header('Location: /results.php');  
        exit(); 
    }
    elseif(($u === 'student2') && ($p === 'password2'))
    {
        setcookie('user', 'STUD2', time() + (86400 * 30), "/");
        header('Location: /results.php');  
        exit();
    }
    elseif(($u === 'student3') && ($p === 'password3'))
    {
        setcookie('user', 'STUD3', time() + (86400 * 30), "/");
        header('Location: /results.php');  
        exit();
    }
    elseif(($u === 'admin') && ($p === 'TH34DM1NP4$$w0rdYooH000'))
    {
        setcookie('user', 'THEADMINCOOKIE44301', time() + (86400 * 30), "/");
        header('Location: /results.php');  
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - University ETAS</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: DarkGray; 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .login-container {
            background-color: #fff;
            padding: 48px; 
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            width: 360px;
        }
        .portal-introduction {
            font-size: 21.6px;
            font-weight: bold;
            margin-bottom: 24px; 
            color: #333;
        }
        .login-container h2 {
            margin-bottom: 24px;
            font-weight: bold;
            font-size: 24px; 
        }
        .login-container input,
        .login-container button {
            width: 100%;
            padding: 12px;
            margin: 12px 0; 
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 18px;
            box-sizing: border-box; 
        }
        .login-container button {
            background-color: #5cb85c;
            border: none;
            color: white;
            cursor: pointer;
        }
        .login-container button:hover {
            background-color: #4cae4c;
        }
        .login-container a {
            display: block;
            margin-top: 10px;
            color: #007bff;
            text-decoration: none;
        }
        .login-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="portal-introduction">
            Welcome to the Portal to View Grades at ETAS University.
        </div>
        <h2>Login</h2>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>

    <!--credentials are in the logins.txt file -->

</body>
</html>
