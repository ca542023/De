from ..services.BaseService import BaseServiceInterface
from ..models.Context import Context, Session, SecurityLevel
from ..models.CommonResponseCodes import CommonResponseCodes
from ..response import BaseResponse, NegativeResponse, PositiveResponse


class WriteDataByIdentifierService(BaseServiceInterface):
    def __init__(
        self,
        request_id: int,
        session_whitelist: set[Session],
        security_level_whitelist: tuple[SecurityLevel],
    ):
        super().__init__(request_id, session_whitelist, security_level_whitelist)

    def run(
        self, context: Context, sub_func_data: bytes
    ) -> tuple[Context, BaseResponse]:
        if len(sub_func_data) < 4:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT
            )

        data_id = int.from_bytes(sub_func_data[:2], "big")
        matched_data_item = context.find_data_item_by_did(data_id)

        if not matched_data_item:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUEST_OUT_OF_RANGE
            )

        # if not allowed in current session
        if (
            matched_data_item.session_whitelist
            and context.active_session not in matched_data_item.session_whitelist
        ):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUEST_OUT_OF_RANGE
            )

        if (
            matched_data_item.security_level_whitelist
            and context.current_security_level
            not in matched_data_item.security_level_whitelist
        ):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.SECURITY_ACCESS_DENIED
            )

        # Return error if overwriting user controlled callable with static value.
        if callable(matched_data_item.data):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.GENERAL_REJECT
            )

        # No sanitization or length check here cause this project is mainly used for (cyber sec) testing,
        # thus overflow and other vulnerabilities can be simulated with this server. If you need it, then implement a
        # conditional sanitize.
        matched_data_item.data = sub_func_data[2:]
        return context, PositiveResponse(
            self.id, matched_data_item.did.to_bytes(2, "big")
        )
