---
path: "/atoms/activityIndicator/guide"
type: "intro"
level: "atoms"
title: "activity indicator"
---

Use this to show the user that waiting for a process to finish is needed.

The activity indicator comes in three sizes:

- `medium` (by default)
- `large`
- `small`, which are controlled by the `-large` and `-small` classes

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
In a live context using the activity indicator, it is highly recommended to switch its <code>aria-live</code> attribute to <code>"polite"</code>.<br/><br/>
More informations can be found <a href="https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/ARIA_Live_Regions" target="_self">here</a>.
</div></div>
