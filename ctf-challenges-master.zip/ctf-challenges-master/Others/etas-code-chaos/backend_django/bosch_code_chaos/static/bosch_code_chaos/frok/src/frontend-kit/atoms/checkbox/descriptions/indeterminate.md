---
path: "/atoms/checkbox/guide"
type: "variant"
level: "atoms"
title: "checkbox"
variant: "indeterminate checkbox"
---

An indeterminate checkbox is neither checked nor unchecked. This state is removed automatically after an interaction with the element. You can use the API to set or unset this state as well.
