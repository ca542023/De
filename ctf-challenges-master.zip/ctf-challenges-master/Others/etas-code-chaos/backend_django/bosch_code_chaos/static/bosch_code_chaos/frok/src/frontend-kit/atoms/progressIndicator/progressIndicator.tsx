import * as React from 'react';
import classNames from 'classnames';

class ProgressIndicatorProps {
  type: string;
  progressId?: string;
  progress?: number;
}

/**
 * @name        a-progress-indicator
 * @type        atom
 *
 * @param       type          Type of indicator. Either determinate or indeterminate. Required.
 * @param       progressId    Identifier for a determinate progress indicator. Optional.
 * @param       progress      Progress of the indicator. Optional.
 *
 * @description
 * representation of a progress indicator
 */

const ProgressIndicator: React.FunctionComponent<ProgressIndicatorProps> = ({
  type,
  progressId,
  progress,
}: ProgressIndicatorProps) => {
  const progressIndicatorTypeClass = classNames('a-progress-indicator', {
    [`-${type}`]: type,
  });

  const progressValue: number = progress || null;

  return (
    <div className="a-progress-indicator-container">
      <progress
        className={progressIndicatorTypeClass}
        id={progressId}
        value={progressValue}
        max={100}
      />
      {type === 'determinate' ? (
        <div className="a-progress-indicator__inner-bar" />
      ) : (
        <div className="a-progress-indicator__anim-bar">
          <div className="a-progress-indicator__inner-bar" />
        </div>
      )}
    </div>
  );
};

export { ProgressIndicator, ProgressIndicatorProps };
