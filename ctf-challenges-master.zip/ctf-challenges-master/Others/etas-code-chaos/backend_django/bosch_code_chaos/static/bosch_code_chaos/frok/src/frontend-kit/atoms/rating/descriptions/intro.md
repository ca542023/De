---
path: "/atoms/rating/guide"
type: "intro"
level: "atoms"
title: "rating"
---

Rating is a visual indicator of the average user ratings based on submitted ratings.

Always consists of five stars. The stars can be completely colored, half colored or displayed as an outline only.

Those stars are radio buttons which can be selected in order to pass the selected value.

The rating can be used in two sizes: small and large and can also be supplemented by a label in each case.

# Use cases

- rating as a link (when clicking or tapping, the user can be redirected to a detailed assessment)
- rating as selection (individual stars can be selected in order to give a rating)
