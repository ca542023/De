const DISABLE_CLICK_THRESHOLD = 10;
const VELOCITY_MULTIPLIER = 0.95;

export default class DragScroll {
  public el: HTMLElement;

  private startX: number;
  private scrollLeft: number;
  private velocityX: number;
  private momentumID: number;
  private mouseDown = false;
  private isTouchDevice: boolean;
  private preventClickEvent = false;

  constructor(el: HTMLElement) {
    this.el = el;

    this.detectTouchDevice();

    this.handleMouseDown = this.handleMouseDown.bind(this);
    this.handleMouseUp = this.handleMouseUp.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
    this.handleMouseMove = this.handleMouseMove.bind(this);
    this.momentumLoop = this.momentumLoop.bind(this);

    this.el.addEventListener('mousedown', this.handleMouseDown);
    this.el.addEventListener('mouseup', this.handleMouseUp);
    this.el.addEventListener('mouseleave', this.handleMouseLeave);
    this.el.addEventListener('mousemove', this.handleMouseMove);
  }

  /**
   * @name  isClickPrevented
   * @description
   * Returns true if the click events should be prevented
   */
  public isClickPrevented(): boolean {
    return this.preventClickEvent;
  }

  /**
   * @name allowClickEvents
   * @description
   * Allows click events to be triggered
   */
  public allowClickEvents(): void {
    this.preventClickEvent = false;
  }

  /**
   * @name preventClickEvents
   * @description
   * Prevents click events from being triggered
   */
  public preventClickEvents(): void {
    this.preventClickEvent = true;
  }

  /**
   * @name detectTouchDevice
   * @description
   * Detects if the device is touch enabled
   */
  private detectTouchDevice(): void {
    const isTouch = matchMedia('(hover: none)').matches;
    this.isTouchDevice = isTouch;
  }

  /**
   * @name handleMouseDown
   * @param {MouseEvent} event
   * @description
   * Handles the mouse down event
   */
  private handleMouseDown(event: MouseEvent): void {
    if (this.isTouchDevice) return;

    this.mouseDown = true;
    this.startX = event.pageX - this.el.offsetLeft;
    this.scrollLeft = this.el.scrollLeft;

    this.cancelMomentumTracking();
  }

  /**
   * @name handleMouseUp
   * @param {MouseEvent} event
   * @description
   * Handles the mouse up event
   */
  private handleMouseUp(event: MouseEvent): void {
    if (this.isTouchDevice) return;

    const current = event.pageX - this.el.offsetLeft;
    const distance = Math.abs(this.startX - current);

    // Check the scrolled distance to determine if click events should be prevented
    if (distance > DISABLE_CLICK_THRESHOLD) {
      this.preventClickEvents();
    }

    this.mouseDown = false;
    this.beginMomentumTracking();
  }

  /**
   * @name handleMouseLeave
   * @description
   * Handles the mouse leave event
   */
  private handleMouseLeave(): void {
    if (this.isTouchDevice) return;

    this.mouseDown = false;
  }

  /**
   * @name handleMouseMove
   * @param {MouseEvent} event
   * @description
   * Handles the mouse move event
   */
  private handleMouseMove(event: MouseEvent): void {
    if (!this.mouseDown || this.isTouchDevice) {
      return;
    }

    event.preventDefault();
    const x = event.pageX - this.el.offsetLeft;
    const scrollDistance = x - this.startX;
    const prevScrollLeft = this.el.scrollLeft;

    this.el.scrollLeft = this.scrollLeft - scrollDistance;
    this.velocityX = this.el.scrollLeft - prevScrollLeft;
  }

  /**
   * @name beginMomentumTracking
   * @description
   * Begins the momentum tracking loop
   */
  private beginMomentumTracking(): void {
    this.cancelMomentumTracking();
    this.momentumID = requestAnimationFrame(this.momentumLoop);
  }

  /**
   * @name cancelMomentumTracking
   * @description
   * Cancels the momentum tracking loop
   */
  private cancelMomentumTracking(): void {
    cancelAnimationFrame(this.momentumID);
  }

  /**
   * @name momentumLoop
   * @description
   * Handles the momentum tracking loop
   */
  private momentumLoop(): void {
    this.el.scrollLeft += this.velocityX;
    this.velocityX *= VELOCITY_MULTIPLIER;

    if (Math.abs(this.velocityX) > 0.5) {
      this.momentumID = requestAnimationFrame(this.momentumLoop);
    }
  }
}
