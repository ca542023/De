import * as React from 'react';

const LiDemonstrator: React.FunctionComponent = () => (
  <ul className="a-list a-list--dot">
    <li>First item</li>
    <li>Second item</li>
    <li>Third item</li>
  </ul>
);

export default LiDemonstrator;
