import pytest

from models import SecurityAccessState
from uds_server.models import Context
from uds_server.models import Session
from uds_server.models import DataItem
from uds_server.models import Memory, AddressLength
from uds_server.models import DownloadUploadJob
from uds_server.models import SecurityLevel


@pytest.fixture
def sample_context():
    return Context(
        Session(0x01, "foo"),
        {Session(0x01, "foo"), Session(0x02, "bar")},
        {DataItem(0x0, "foo", 0x0, b"")},
        Memory(AddressLength.bit_16),
    )


def test_download_upload_job(sample_context):
    sample_context.download_upload_job = DownloadUploadJob(0x02, 0x02)
    dj2 = sample_context.download_upload_job
    assert (
            sample_context.download_upload_job.total_size == dj2.total_size
            and sample_context.download_upload_job.start_address == dj2.start_address
    )


def test_memory(sample_context):
    sample_context.memory = Memory(AddressLength.bit_32)
    m = sample_context.memory
    assert m.address_length.value == sample_context.memory.address_length.value


def test_security_access_attempts(sample_context):
    sample_context.security_access_attempts = 99
    saa = sample_context.security_access_attempts
    assert saa == 99


def test_security_levels(sample_context):
    sl = {SecurityLevel(0x02)}
    sample_context.security_levels = sl
    sl2 = sample_context.security_levels
    assert sl == sl2


def test_active_session(sample_context):
    assert sample_context.active_session.session_id == 0x01


def test_sessions(sample_context):
    assert len(sample_context.sessions) == 2


def test_current_security_level(sample_context):
    sample_context.current_security_level = 0x03
    assert sample_context.current_security_level == 0x03


def test_data_items(sample_context):
    assert len(sample_context.data_items) == 1


def test_current_seed(sample_context):
    sample_context.current_seed = b"\x00"
    assert sample_context.current_seed == b"\x00"


def test_reset_security_level_blocked(sample_context):
    sample_context.current_security_access_state = SecurityAccessState.BLOCKED
    sample_context.reset_security_level()
    assert sample_context.current_security_access_state == SecurityAccessState.BLOCKED


def test_reset_security_level(sample_context):
    sample_context.current_security_access_state = SecurityAccessState.WAIT_FOR_KEY
    sample_context.current_seed = b"\x00"
    sample_context.current_security_level = SecurityLevel(0x01)
    sample_context.reset_security_level()
    assert (
            sample_context.current_security_access_state
            == SecurityAccessState.WAIT_FOR_SEED
            and sample_context.current_seed is None
            and sample_context.current_security_level is None
    )


def test_unblock_security_access(sample_context):
    sample_context.security_access_attempts = 10
    sample_context.current_security_access_state = SecurityAccessState.BLOCKED

    sample_context.unblock_security_access()

    assert (
            sample_context.security_access_attempts == 0
            and sample_context.current_security_access_state
            == SecurityAccessState.WAIT_FOR_SEED
    )


def test_find_session_not_existing(sample_context):
    assert sample_context.find_session(0x03) is None


def test_find_session(sample_context):
    assert sample_context.find_session(0x01).session_id == 0x01


def test_find_data_item_by_did(sample_context):
    assert sample_context.find_data_item_by_did(0x0).did == 0x0


def test_get_security_level(sample_context):
    sl = {SecurityLevel(0x01)}
    sample_context.security_levels = sl
    rsl = sample_context.get_security_level(0x01)
    assert rsl.security_level_requestSeed_id == 0x01 and rsl.security_level_sendKey_id == 0x02


def test_get_security_level_none(sample_context):
    sl = {SecurityLevel(0x01)}
    sample_context.security_levels = sl
    assert sample_context.get_security_level(0x05) is None

