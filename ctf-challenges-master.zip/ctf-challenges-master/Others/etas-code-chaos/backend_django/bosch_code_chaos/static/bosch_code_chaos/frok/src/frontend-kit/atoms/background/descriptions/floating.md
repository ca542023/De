---
path: "/atoms/background/guide"
type: "variant"
level: "atoms"
title: "background"
variant: "floating"
---

Use the floating background to add a depth effect **WITHOUT** a box shadow.
