import * as React from "react";

const FigcaptionDemonstrator: React.FunctionComponent = () => (
    <figcaption>Example figcaption</figcaption>
    )

export default FigcaptionDemonstrator;