import pytest

from uds_server.models import DefaultSecurityCryptoProvider


@pytest.fixture
def default_security_crypto_provider():
    return DefaultSecurityCryptoProvider()


def test_generate_seed_length(default_security_crypto_provider):
    seed: bytes = default_security_crypto_provider.generateSeed(associated_data=None)
    assert len(seed) == 4


def test_generate_seed_without_associate_data(default_security_crypto_provider):
    zero_seed: bytes = b'\x00\x00\x00\x00'
    seed: bytes = default_security_crypto_provider.generateSeed(associated_data=None)
    assert seed != zero_seed


def test_generate_seed_with_associate_data(default_security_crypto_provider):
    zero_seed: bytes = b'\x00\x00\x00\x00'
    associated_data = b'\x11\x11\x11\x11'
    seed: bytes = default_security_crypto_provider.generateSeed(associated_data=associated_data)
    assert seed != zero_seed and seed != associated_data


def test_generate_key(default_security_crypto_provider):
    zero_key: bytes = b'\x00\x00\x00\x00'
    key: bytes = default_security_crypto_provider.generateKey(b'\x00\x00\x00\x00')
    assert zero_key != key


def test_generate_security_crypto_provider_key():
    DefaultSecurityCryptoProvider(b'\x01\x02\x03\x04')
