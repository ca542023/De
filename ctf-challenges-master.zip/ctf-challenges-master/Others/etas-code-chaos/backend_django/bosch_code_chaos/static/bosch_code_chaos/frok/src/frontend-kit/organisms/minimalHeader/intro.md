---
path: "/organisms/minimalHeader/guide"
type: "intro"
level: "organisms"
title: "Minimal Header"
---

The minimal header can be used in SPAs or generally, when the content is presented in an app-like manner.

To ensure consistent behavior, the content should be inserted into a `div` with the `e-container` class, while giving the user control over the vertical styling (see the "Minimal Header with Content" demo below).
