from ..models import (
    Context,
    Session,
    SecurityLevel,
    SecurityAccessState,
    CommonResponseCodes,
)
from ..models import BaseSecurityCryptoProvider
from ..response import NegativeResponse, BaseResponse, PositiveResponse
from ..services.BaseService import BaseServiceInterface


class SecurityAccessService(BaseServiceInterface):
    def __init__(
        self,
        requestSID: int = 0x27,
        session_whitelist: set[Session] = None,
        security_level_whitelist: tuple[SecurityLevel] = None,
        max_attempts: int = 5,
    ):
        # Service is available in every session and by every security level
        super().__init__(requestSID, session_whitelist, security_level_whitelist)
        self._max_attempts = max_attempts

    def run(
        self, context: Context, sub_func_data: bytes
    ) -> tuple[Context, BaseResponse]:
        # Uneven sub_func indicates requestSeed
        if len(sub_func_data) <= 0:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT
            )

        # Ignore suppressPosRespMsgIndicationBit

        security_access_type_raw = int.from_bytes(sub_func_data[:1], 'big')
        security_level_raw = (
            security_access_type_raw
            if security_access_type_raw % 2 == 1
            else security_access_type_raw - 1
        )
        security_level = SecurityLevel(security_level_raw)
        associated_data = sub_func_data[1:]

        if (
            not security_level
            or security_level not in context.security_levels_unlock.keys()
        ):
            return context, NegativeResponse(
                self.id, CommonResponseCodes.SUB_FUNCTION_NOT_SUPPORTED
            )

        if context.current_security_access_state == SecurityAccessState.BLOCKED:
            return context, NegativeResponse(
                self.id, CommonResponseCodes.REQUIRED_TIME_DELAY_NOT_EXPIRED
            )

        current_crypto_provider: BaseSecurityCryptoProvider = (
            context.security_levels_unlock.get(security_level)
        )

        # Request Seed request
        if (
            security_access_type_raw % 2 == 1
            and context.current_security_access_state
            == SecurityAccessState.WAIT_FOR_SEED
        ):
            context.current_seed = current_crypto_provider.generate_seed(
                associated_data
            )
            print(context.current_seed)
            context.current_security_access_state = SecurityAccessState.WAIT_FOR_KEY
            return context, PositiveResponse(
                self.id,
                security_access_type_raw.to_bytes(1, 'big') + context.current_seed,
            )

        # Send Key request
        if (
            security_access_type_raw % 2 == 0
            and context.current_security_access_state
            == SecurityAccessState.WAIT_FOR_KEY
        ):
            equal_keys = False

            # Compute challenge
            challenge = current_crypto_provider.generate_key(context.current_seed)
            # Check if crypto provider implements own equal function, if not use simple compare
            if current_crypto_provider.provider_implements_equal():
                equal_keys = current_crypto_provider.equal(challenge, associated_data)
            else:
                equal_keys = challenge == associated_data

            print(challenge)
            # Reset state machine
            context.current_security_access_state = SecurityAccessState.WAIT_FOR_SEED
            if equal_keys:
                context.current_security_level = security_level
                return context, PositiveResponse(
                    self.id, security_access_type_raw.to_bytes(1, 'big')
                )

            if context.security_access_attempts >= self._max_attempts:
                context.current_security_access_state = SecurityAccessState.BLOCKED
                return context, NegativeResponse(
                    self.id, CommonResponseCodes.EXCEEDED_NUMBER_OF_ATTEMPTS
                )
            context.security_access_attempts += 1
            return context, NegativeResponse(self.id, CommonResponseCodes.INVALID_KEY)

        return context, NegativeResponse(
            self.id, CommonResponseCodes.REQUEST_SEQUENCE_ERROR
        )
