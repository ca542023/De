from .security.SecurityLevel import SecurityLevel
from .Session import Session
import typing


class DataItem:
    def __init__(
        self,
        did: int,
        name: str,
        address: int,
        data: bytes | typing.Callable[[], bytes],
        session_whitelist: set[Session] = None,
        security_level_whitelist: tuple[SecurityLevel] = None,
    ):
        if did > 0xFFFF:
            raise ValueError("DID must not exceed 2-byte.")
        self.did = did
        self.name = name
        self.address = address
        self.data = data
        self.session_whitelist = session_whitelist
        self.security_level_whitelist = security_level_whitelist

    @property
    def did(self) -> int:
        return self._did

    @did.setter
    def did(self, value: int):
        self._did = value

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str):
        self._name = value

    @property
    def address(self) -> int:
        return self._address

    @address.setter
    def address(self, value: int):
        self._address = value

    @property
    def data(self) -> bytes | typing.Callable[[], bytes]:
        return self._data

    @data.setter
    def data(self, value: bytes | typing.Callable[[], bytes]):
        self._data = value

    @property
    def session_whitelist(self) -> set[Session]:
        return self._session_whitelist

    @session_whitelist.setter
    def session_whitelist(self, value: set[Session]):
        self._session_whitelist = value

    @property
    def security_level_whitelist(self) -> tuple[SecurityLevel]:
        return self._security_level_whitelist

    @security_level_whitelist.setter
    def security_level_whitelist(self, value: tuple[SecurityLevel]):
        self._security_level_whitelist = value
