---
path: "/atoms/accordion/guide"
type: "intro"
level: "atoms"
title: "accordion"
---

An Accordion is a vertically stacked list of elements with show/hide functionality. Tapping or clicking on the arrow icon opens the Accordion.

<div class="frontend-kit__notification a-notification -warning"><i class="a-icon ui-ic-alert-warning"></i><div class="a-notification__content">
Each variant has a button with an <code>id</code> in the headline. In order to have all the aria-attributes set correctly, this <code>id</code> needs to be unique and set by the user.
</div></div>
