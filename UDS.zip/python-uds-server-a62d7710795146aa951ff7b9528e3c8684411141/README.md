<!--
    - Version: 1.0.1

    - Please don't add additional sections to this README since several information should be kept in the confluence only (especially metadata). If you feel that something is actually missing, please contact the responsible for Tool Development (https://confluence.intranet.escrypt.com/confluence/x/boLYBw).

    - Wondering what this markup language is? It's called Markdown (.md) and is widely used for documentation purposes. See https://confluence.atlassian.com/bitbucketserver/markdown-syntax-guide-776639995.html for an introduction.

    - See https://www.makeareadme.com/ for further explanations and examples for what to put in the following sections.

    - The canonical source for this template is: https://bitbucket.intranet.escrypt.com/bitbucket/projects/PT/repos/template/browse/README.md. Changes to the template should only be made there and propagated to the respective repositories.
-->
> PROJECT IS CURRENTLY UNDER REFACTORING. See [here](https://bitbucket-escrypt.boschdevcloud.com/projects/PT/repos/python-uds-server) for original UDS Server.

# python-uds-server
ISO 14229 compliant python implementation of the UDS application layer protocol.
For meta information such as owner and development status, see the entry in the [List of Tools][list of tools].
>Important: This project **does not** provide a **full functional and secure UDS server implementation for productive usage**. Rather should be used exclusively for demo purposes or (cyber security) testing.

<!-- Don't delete the following note! -->

# Installation
<!-- For Python projects use of pip is strongly recommended. Try not to directly call setup.py. See https://pip.pypa.io/en/stable/reference/pip_install/#pip-install-examples for the most common usages of the 'pip install' command. -->

Using pip:

    pip3 install -e .


<!-- Use the 'Requirements' section only if there are some special requirements or dependencies that are not covered by the installation steps above. -->

<!-- ## Requirements -->

# Contributing
Contributions of any kind (feedback, merge requests, missing features, etc.) are always welcome. Please open pull requests for contributions.

<!-- Links used in this document -->
[list of tools]: https://confluence.intranet.escrypt.com/confluence/x/kwRZC
