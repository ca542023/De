from abc import ABC


class BaseRequest(ABC):
    # TODO implement subfunction and parameterized subclasses
    def __init__(self, service_id=0x00, body=None):
        self.service_id = service_id
        # TODO split body to subfunction and parameter for certain request ids according to ISO14229
        self.body = body

    @property
    def service_id(self):
        return self._service_id

    @service_id.setter
    def service_id(self, value):
        self._service_id = value

    @property
    def body(self):
        return self._body

    @body.setter
    def body(self, value):
        self._body = value
    def get_body(self) -> bytes:
        return self._body
