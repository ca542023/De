---
path: "/molecules/table/guide"
type: "intro"
level: "molecules"
title: "table"
---

A table can be used to display structured data.

Individual table cells can be modified to display their text bold or highlight themself by changing the background color. Therefore you can mix the styles to create a header on the top, the side, the top and side or as creative as you want it to be! More details about the table cells can be found under _Atoms > Table cell_.
