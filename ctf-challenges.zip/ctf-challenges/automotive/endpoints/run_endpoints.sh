#!/bin/bash

interface=$1
[[ -z $interface ]] && exit 1

regex="${interface}@[^:]+:.*state UP"
echo "Waiting for ${interface} ..."
while read -r line; do
    [[ $line =~ $regex ]] && break
done < <(ip monitor)
echo "${interface} seems to be up!"

python3 src/run_endpoints.py "$interface"
