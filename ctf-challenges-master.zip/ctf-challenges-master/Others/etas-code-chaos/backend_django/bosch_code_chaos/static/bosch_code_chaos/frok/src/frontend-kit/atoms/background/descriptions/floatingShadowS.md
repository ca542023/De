---
path: "/atoms/background/guide"
type: "variant"
level: "atoms"
title: "background"
variant: "floating shadow s"
---

Use the floating shadow s background to add a depth effect, using a box shadow of 0.5rem. See [Box](/atoms/box/guide) for a usage example.
