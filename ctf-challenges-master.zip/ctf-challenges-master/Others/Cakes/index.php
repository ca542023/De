<?php
ini_set('display_errors', 'off');
session_start();

require_once '/var/www/html/twig/lib/Twig/lib/Twig/Autoloader.php';
Twig_Autoloader::register();

$loader = new Twig_Loader_Array([
    'title' => '<title>Top Cakes - ' . $_GET['hname'] . ' | Yummy</title>',
    'Cake_1' => file_get_contents('txt/cake_1.txt'), // Chocolate Layer Cake
    'Cake_2' => file_get_contents('txt/cake_2.txt'), // Berry Vanilla Dream Cake
    'Cake_3' => file_get_contents('txt/cake_3.txt'), // Rainbow Surprise Cake
    'Cake_4' => file_get_contents('txt/cake_4.txt'), // Caramel Drizzle Delight
    'Cake_5' => file_get_contents('txt/cake_5.txt'), // Pink Lemonade Cake
    'Cake_6' => file_get_contents('txt/cake_6.txt'), // Fudgy Walnut Brownie Cake
    'Cake_7' => file_get_contents('txt/cake_7.txt'), // Berry Chocolate Bliss
    'Cake_8' => file_get_contents('txt/cake_8.txt'), // Midnight Chocolate Delight
    'Cake_9' => file_get_contents('txt/cake_9.txt'), // Raspberry Victoria Sponge Cake
    'Cake_10' => file_get_contents('txt/cake_10.txt'), // Raspberry Birthday Cake
    'Cake_11' => file_get_contents('txt/cake_11.txt'), // Classic Pumpkin Pie
    'Cake_12' => file_get_contents('txt/cake_12.txt'), // Raspberry Chocolate Layer Cake
    'Cake_13' => file_get_contents('txt/cake_13.txt'), // No-Bake Chocolate Cheesecake
    'Cake_14' => file_get_contents('txt/cake_14.txt'), // Chocolate Pecan Tart
    'Cake_15' => file_get_contents('txt/cake_15.txt'), // Lemon Raspberry Drip Cake
]);

$twig = new Twig_Environment($loader);

$loader2 = new Twig_Loader_Filesystem("templates");
$twig2 = new Twig_Environment($loader2);


if (isset($_GET['hname']) || $_GET['hname'] != "") {
    if (preg_match("/^$/",$_GET['hname']) || preg_match("/^'.*/",$_GET['hname']) || preg_match("/^\".*/",$_GET['hname']))
        die('<h2 align=center>LOL no cake for you! ^_^</h2>');
    else
        print $twig->render('title', array('hname' => "{{" . $_GET['hname'] . "}}")) or die("error!");
}

$options = [];

switch ($_GET['hname'] ?? '') {
    case "Cake_1":
    case "Cake_2":
    case "Cake_3":
    case "Cake_4":
    case "Cake_5":
    case "Cake_6":
    case "Cake_7":
    case "Cake_8":
    case "Cake_9":
    case "Cake_10":
    case "Cake_11":
    case "Cake_12":
    case "Cake_13":
    case "Cake_14":
    case "Cake_15":
        $options[$_GET['hname']] = 'active';
        echo $twig2->render('head.html', $options);
        describe($_GET['hname'], $twig->render($_GET['hname']));
        break;
    default:
        echo $twig2->render('head.html', $options);
        echo '<title>Top Cakes - Index</title>';
        echo $twig2->render('indexpage.html');
        break;
}

function describe($cake, $description) {
    $image_file = strtolower($cake) . '.jpg';
    ?>
    <h2 align=center><?php print $cake;?></h2>
    <h3><center><img width="800" height="600" src="img/<?php print $image_file; ?>"></center></h3>
    <h3 style="margin-left:5%; margin-right:10%">
        <center><div class="alert alert-success"><?php print $description; ?></div></center>
    </h3>
    <?php
}

?>

