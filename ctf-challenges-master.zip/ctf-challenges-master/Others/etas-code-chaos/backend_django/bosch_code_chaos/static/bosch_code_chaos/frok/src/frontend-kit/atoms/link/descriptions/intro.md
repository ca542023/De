---
path: "/atoms/link/guide"
type: "intro"
level: "atoms"
title: "link"
---

The basic link element is underlined by default.
It also supports the following variants:

- `primary`: It's a link (not underlined) with an arrow on the right.
- `integrated`: It a link without a background.
- `integrated highlight`: It's an integrated link highlighted. It supports sizes from 'S' to '6XL'.
- `look-alike primary button`: It's a link which looks and behave like a primary button.
- `look-alike secondary button`: It's a link which looks and behave like a secondary button.

Each variant can:

- have an icon either on the right or on the left
- have an optional aria-label which needs to be set by the user
- be disabled
