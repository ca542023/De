class MemoryFrame:

    def __init__(self, total_size: int, start_address: int, writeable: bool):
        if total_size <= 0:
            raise ValueError('Frame size must be greater than zero.')
        self.frame_data: bytearray = bytearray(total_size)
        self.total_size: int = total_size
        self.start_address: int = start_address
        self.writeable: bool = writeable

    def read(self, address: int, length: int):
        if address < self.start_address:
            raise ValueError('Attempt to under read frame.')
        if address+length > self.start_address + self.total_size:
            raise ValueError('Attempt to over read frame.')
        frame_offset = address - self.start_address
        return self.frame_data[frame_offset: frame_offset + length]

    def write(self, address: int, data: bytearray):
        if address < self.start_address:
            raise ValueError('Attempt to under read frame.')
        if address+len(data) > self.start_address + self.total_size:
            raise ValueError('Attempt to over read frame.')
        frame_offset = address - self.start_address
        self.frame_data[frame_offset: frame_offset + len(data)] = data
        return True
