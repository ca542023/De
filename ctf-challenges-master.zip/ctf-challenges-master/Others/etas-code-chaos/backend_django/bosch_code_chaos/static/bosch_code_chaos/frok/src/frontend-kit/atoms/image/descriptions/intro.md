---
path: "/atoms/image/guide"
type: "intro"
level: "atoms"
title: "image"
---

Image elements can be used with or without caption.

<div class="frontend-kit__notification a-notification -neutral"><i class="a-icon ui-ic-alert-info"></i><div class="a-notification__content">
    Since IE 11 does not support <code>srcset</code> or related functionality, always include a <code>src</code> attribute as fallback.
</div></div>
