<?php

$resultMessage = '';

if (!empty($_POST)) {
    $ip = $_POST['ip'];

    $result = exec('ping -c 2 ' . $ip);

    if (strpos($result, 'avg') !== false) {
        $resultMessage = 'The machine is up ^_^';
    } else {
        $resultMessage = 'The machine is down :/';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server Availability Test</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: DarkGray;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .test-container {
            background-color: #fff;
            padding: 48px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            width: 480px;
        }
        .test-container h1 {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 24px;
        }
        .test-container form input[type="text"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 24px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        .test-container form input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #5cb85c;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 19.2px;
            cursor: pointer;
        }
        .test-container form input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .test-container .result-message {
            font-size: 18px;
            color: #333;
            margin-top: 24px;
        }
    </style>
</head>
<body>
    <div class="test-container">
        <h1>Server Availability Test</h1>
        <form action="boiler.php" method="post">
            <input type="text" name="ip" placeholder="Enter IP address"></input>
            <input type="submit" value="Submit"></input>
        </form>
        <div class="result-message">
            <?php

            echo $resultMessage;
            ?>
        </div>
    </div>
</body>
</html>
