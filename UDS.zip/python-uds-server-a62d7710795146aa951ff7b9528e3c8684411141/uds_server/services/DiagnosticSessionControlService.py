from .BaseService import BaseServiceInterface
from ..models import Context, Session, CommonResponseCodes
from ..response import PositiveResponse, BaseResponse, NegativeResponse


class DiagnosticSessionControlService(BaseServiceInterface):
    _session_transitions: dict[Session, set[Session]] = None

    def __init__(self, requestSID: int = 0x10, session_transitions: dict[Session, set[Session]] = None):
        """

        :param requestSID: The service identifier as integer :param session_transitions: Should specify which session
        change is allowed for the current session. dict[FromSession, {ToSession1, ToSession2}]. If parameter is none
        unrestricted session changes are possible
        """
        # Service is available in every session and by every security level
        # noinspection PyTypeChecker
        super().__init__(requestSID, None, None)
        self._session_transitions = session_transitions

    def session_change(self, to_session_id: int, context: Context) -> tuple[Context, BaseResponse]:
        current_session = context.active_session

        # Session not defined
        if current_session not in context.sessions:
            return context, NegativeResponse(self.id, CommonResponseCodes.SUB_FUNCTION_NOT_SUPPORTED)

        # Session not existing

        matched_session = context.find_session(to_session_id)

        if not matched_session:
            return context, NegativeResponse(self.id, CommonResponseCodes.SUB_FUNCTION_NOT_SUPPORTED)

        to_session = matched_session
        # Session transition not allowed
        if self._session_transitions and to_session not in self._session_transitions.get(current_session):
            return context, NegativeResponse(self.id, CommonResponseCodes.SUB_FUNCTION_NOT_SUPPORTED)
            # todo session transition not defined return NRC
        context.active_session = to_session
        return context, PositiveResponse(self.id, to_session_id)

    def run(self, context: Context, sub_func_data: bytes) -> tuple[Context, BaseResponse]:
        sub_fun_identifier = int.from_bytes(sub_func_data, 'big')
        self.set_suppress_positive_resp_bit(sub_fun_identifier)

        if len(sub_func_data) > 1:
            return context, NegativeResponse(self.id,
                                             CommonResponseCodes.INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT)

        return self.session_change(int.from_bytes(sub_func_data, 'big'), context)
