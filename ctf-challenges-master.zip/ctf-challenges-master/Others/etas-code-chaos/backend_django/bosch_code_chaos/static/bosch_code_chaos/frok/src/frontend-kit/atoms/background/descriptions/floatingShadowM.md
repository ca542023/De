---
path: "/atoms/background/guide"
type: "variant"
level: "atoms"
title: "background"
variant: "floating shadow m"
---

Use the floating shadow m background to add a depth effect, using a box shadow of 1rem. See [Box](/atoms/box/guide) for a usage example.
