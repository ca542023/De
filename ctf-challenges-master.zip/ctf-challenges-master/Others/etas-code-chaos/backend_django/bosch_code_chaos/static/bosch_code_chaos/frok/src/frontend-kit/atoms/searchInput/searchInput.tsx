/* eslint-disable import/prefer-default-export */
import * as React from 'react';

import { Icon } from '../icon/icon';

interface SearchInputProps {
  label?: string;
  id: number;
  name: string;
  placeholder?: string;
  isDisabled?: boolean;
  readOnly?: boolean;
}

/**
 * @name      a-search-input
 * @type      atom
 * @author    Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @param   {string} label          Label to Display
 * @param   {number} id             Unique ID for each search input
 * @param   {string} name           Unique name for each search input
 * @param   {string} placeholder    Placeholder of search input
 * @param   {boolean} isDisabled    Wether or not the search input is disabled
 * @param   {boolean} readOnly      Wether or not the search input is read only
 *
 * @description
 * representation of search input
 */
const SearchInput: React.FunctionComponent<SearchInputProps> = ({
  label,
  id,
  name,
  placeholder,
  isDisabled,
  readOnly,
}) => {
  const idSearchInput = `search-input-${id}`;

  return (
    <div className="a-search-input">
      {label && <label htmlFor={idSearchInput}>{label}</label>}
      <input
        type="search"
        id={idSearchInput}
        name={name}
        placeholder={placeholder}
        disabled={isDisabled}
        readOnly={readOnly}
      />
      <button type="button" className="a-search-input__icon-close">
        <Icon isUiIcon iconName="close-small" />
      </button>
    </div>
  );
};

export { SearchInput, SearchInputProps };
