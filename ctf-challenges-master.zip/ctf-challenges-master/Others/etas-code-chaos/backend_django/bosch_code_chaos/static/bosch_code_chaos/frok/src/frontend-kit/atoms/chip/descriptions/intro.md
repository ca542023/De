---
path: "/atoms/chip/guide"
type: "intro"
level: "atoms"
title: "chip"
---

Chips are interactive elements and should be presented as a group to narrow down a topic. Among other things, chips enable searching or filtering content using keywords.


