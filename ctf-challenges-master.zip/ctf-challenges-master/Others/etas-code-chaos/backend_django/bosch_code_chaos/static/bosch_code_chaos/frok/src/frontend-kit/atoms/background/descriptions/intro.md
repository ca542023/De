---
path: "/atoms/background/guide"
type: "intro"
level: "atoms"
title: "background"
---

These are a couple of classes that another background to your elements. Look for the special cases of `-floating`, `-floating-shadow-s`, `-floating-shadow-m` and `-dimmed` below.

<div class="frontend-kit__notification a-notification -neutral"><i class="a-icon ui-ic-alert-info"></i><div class="a-notification__content">
    The <code>frontend-kit-example_…</code> classes throughout this documentation are <em>not</em> part of the element in question and serve only demonstrative purposes.
</div></div>
