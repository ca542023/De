from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError


class SimulatedEmail(models.Model):
    sender = models.CharField(max_length=100)
    recipient = models.CharField(max_length=100)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    date_sent = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.date_sent) + " - " + self.subject


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    security_question_1 = models.CharField(max_length=100)
    security_question_2 = models.CharField(max_length=100)
    profile_picture = models.ImageField(upload_to='profile_pictures/', blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['security_question_1', 'security_question_2']

    def __str__(self):
        return self.email


class EmailVerification(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    token = models.CharField(max_length=100)
    failed_attempts = models.PositiveIntegerField(default=0)
    expiry_date = models.DateTimeField()

    def __str__(self):
        return str(self.user)


def validate_positive_value(value):
    if value < 0:
        raise ValidationError('The purchase cost must be a non-negative value.')


class InventoryItem(models.Model):
    VISIBILITY_CHOICES = [
        ('private', 'Private'),
        ('group', 'Group'),
        ('public', 'Public'),
    ]

    name = models.CharField(max_length=255)
    created_by = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    description = models.TextField(blank=True, null=True)
    serial_number = models.CharField(max_length=100, blank=True, null=True)
    manufacturer = models.CharField(max_length=100, blank=True, null=True)
    visibility = models.CharField(max_length=10, choices=VISIBILITY_CHOICES, default='private')
    purchase_cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, validators=[validate_positive_value])
    purchase_date = models.DateField(blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.name
        

class CTF(models.Model):
    name = models.CharField(max_length=100, unique=True)
    flag = models.CharField(max_length=255)
    found = models.BooleanField(default=False)
    found_at = models.DateTimeField(null=True, blank=True)
    description = models.TextField(blank=True, null=True)
    difficulty = models.IntegerField(default=1)

    def mark_as_found(self):
        self.found = True
        self.found_at = timezone.now()
        self.save()

    def __str__(self):
        return f"{self.name} - {'Found' if self.found else 'Not Found'}"
