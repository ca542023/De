#!/bin/bash

while read -r cnt_name; do
    printf '%s: %s\n' "$cnt_name" "$(docker logs "$cnt_name" | grep -m 1 'container info --')"
done < <(docker ps --format="{{.Names}}" -f "name=^ctf_[0-9]+$" | sort -V)
