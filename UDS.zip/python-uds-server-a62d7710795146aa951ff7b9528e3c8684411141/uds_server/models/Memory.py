from enum import IntEnum

from .MemoryFrame import MemoryFrame


class AddressLength(IntEnum):
    bit_8 = 8,
    bit_16 = 16,
    bit_32 = 32,
    bit_64 = 64,


class Memory:

    def __init__(self, address_length: AddressLength):
        self.address_length: AddressLength = address_length
        self.frames: dict[int, MemoryFrame] = {}

    def add_frame(self, total_size: int, start_address: int, writeable: bool):

        # noinspection PyTypeChecker
        if start_address >= 2**self.address_length.value:
            raise ValueError('Frame address length does not match configured memory address length.')
        for frame_start_address, frame in self.frames.items():
            if frame_start_address < start_address <= frame_start_address + frame.total_size:
                raise ValueError('Overlapping memory frames.')
        if total_size > 2 ** self.address_length.value:
            raise ValueError(f'Total size exceeded possible value for {self.address_length.value}-byte address.')

        self.frames[start_address] = MemoryFrame(total_size=total_size, start_address=start_address,
                                                 writeable=writeable)

    def _try_get_frame_for_address(self, address) -> MemoryFrame | None:
        # noinspection PyTypeChecker
        if address >= 2**self.address_length.value:
            raise ValueError('Address length does not match configured memory address length.')

        for frame_start_address, frame in self.frames.items():
            if frame_start_address <= address <= frame_start_address + frame.total_size:
                return frame

        return None

    def read(self, address, length) -> bytes:
        frame = self._try_get_frame_for_address(address)
        if frame:
            read_data = frame.read(address, length)
            if type(read_data) == int:
                return bytes([read_data])
            else:
                return bytes(read_data)
        else:
            raise ValueError(f'No frame found for address {address}')

    def write(self, address: int, data: bytes) -> bool:
        frame = self._try_get_frame_for_address(address)
        if frame:
            if not frame.writeable:
                raise PermissionError('Frame not writeable.')
            if frame:
                return frame.write(address, bytearray(data))
        else:
            raise ValueError(f'No frame found for address {address}')
