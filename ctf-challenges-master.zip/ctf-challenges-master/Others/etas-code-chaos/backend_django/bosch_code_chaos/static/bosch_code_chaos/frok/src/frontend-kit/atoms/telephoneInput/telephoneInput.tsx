/* eslint-disable import/prefer-default-export */
import * as React from 'react';

interface TelephoneInputProps {
  label: string;
  id: number;
  name: string;
  placeholder?: string;
  isDisabled?: boolean;
  readOnly?: boolean;
}

/**
 * @name      a-telephone-input
 * @type      atom
 * @author    Experience One AG
 * @copyright Robert Bosch GmbH
 *
 * @param   {string} label          Label to Display
 * @param   {number} id             Unique ID for each telephone input
 * @param   {string} name           Unique name for each telephone input
 * @param   {string} placeholder    Placeholder of telephone input
 * @param   {boolean} isDisabled    Wether or not the telephone input is disabled
 * @param   {boolean} readOnly      Wether or not the telephone input is read only

 *
 * @description
 * representation of telephone input
 */

const TelephoneInput: React.FunctionComponent<TelephoneInputProps> = ({
  label,
  id,
  name,
  placeholder,
  isDisabled,
  readOnly,
}) => {
  const idTelephoneInput = `telephone-input-${id}`;

  return (
    <div className="a-telephone-input">
      {label && <label htmlFor={idTelephoneInput}>{label}</label>}
      <input
        type="tel"
        id={idTelephoneInput}
        name={name}
        placeholder={placeholder}
        disabled={isDisabled}
        readOnly={readOnly}
      />
    </div>
  );
};

export { TelephoneInput };
