#!/usr/bin/python3

import socket
import threading
from random import randint

host = '0.0.0.0'
port = 9999

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind((host, port))
sock.listen(5)

def clientthread(conn):
    conn.settimeout(5)
    try:
        conn.send("HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n".encode())
        conn.send('Heyyy .. looking for some math .. my pleasure .. you have to be fast\n'.encode())
        conn.send('Starting math problems:\n'.encode())
        
        for x in range(0, 30):  
            rand1 = randint(50, 9999)
            rand2 = randint(50, 9999)
            op = ['+', '-', '*', '/']
            op_rand = randint(0, 3)

            try:
                conn.send(f"{rand1}{op[op_rand]}{rand2}\n".encode())
            except BrokenPipeError:
                print("Connection broken, client likely disconnected.")
                break

            try:
                data = conn.recv(1024).decode().strip()
            except TimeoutError:
                print("Connection timed out, closing connection.")
                conn.close()
                return

            if not data.isdigit():
                print(f"Received non-integer data: {data}")
                continue

            print(f"{rand1} {op[op_rand]} {rand2} = ")

            res = 0
            if op[op_rand] == '+':
                res = rand1 + rand2
            elif op[op_rand] == '-':
                res = rand1 - rand2
            elif op[op_rand] == '*':
                res = rand1 * rand2
            elif op[op_rand] == '/':
                res = rand1 // rand2  

            print(f"Expected result: {res}")

            if int(data) == res:
                continue
            else:
                conn.send('LOL .. your math skillz suck \n'.encode())
                conn.close()
                break

        # FLAG      
        try:
            with open('/home/developer/flag.txt', 'r') as flag_file:
                flag = flag_file.read().strip()  #
            conn.send(f'{flag} \n'.encode())
            print('Flag sent to client.')
        except FileNotFoundError:
            conn.send('Error: Flag file not found.\n'.encode())
            print('Error: Flag file not found.')

        conn.close()

    except Exception as e:
        print(f"Error: {e}")
        conn.close()

while True:
    conn, addr = sock.accept()
    print(f"Connection established with {addr}")
    threading.Thread(target=clientthread, args=(conn,)).start()

sock.close()
