import * as React from "react";

const H5Demonstrator: React.FunctionComponent = () => (
    <h5>Example headline</h5>
    )

export default H5Demonstrator;