from .BaseResponse import BaseResponse
from ..models.CommonResponseCodes import CommonResponseCodes


class NegativeResponse(BaseResponse):
    _negative_resp_service_ident: int = 0x7F

    def __init__(self, service_id: int, common_response_code: CommonResponseCodes,
                 negative_resp_service_ident: int = 0x7F):
        super().__init__(service_id, common_response_code)
        self._negative_resp_service_ident = negative_resp_service_ident

    def encode(self):
        return self._negative_resp_service_ident.to_bytes(1, 'big') + \
               self._service_id.to_bytes(1, 'big') + \
               self._common_response_code.value.to_bytes(1, 'big')
