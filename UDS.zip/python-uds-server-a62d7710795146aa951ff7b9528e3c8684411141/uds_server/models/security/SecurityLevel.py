class SecurityLevel:
    def __init__(self, security_level_requestSeed_id: int = 0x01):
        self.security_level_requestSeed_id = security_level_requestSeed_id

    def __eq__(self, other) -> bool:
        if not other:
            return False
        return (
            self._security_level_requestSeed_id == other._security_level_requestSeed_id
            and self._security_level_sendKey_id == other._security_level_sendKey_id
        )

    def __hash__(self) -> int:
        return hash(
            (self._security_level_requestSeed_id, self._security_level_sendKey_id)
        )

    @property
    def security_level_requestSeed_id(self) -> int:
        return self._security_level_requestSeed_id

    @security_level_requestSeed_id.setter
    def security_level_requestSeed_id(self, value: int):
        self._security_level_requestSeed_id = value
        self._security_level_sendKey_id = value + 1

    @property
    def security_level_sendKey_id(self):
        return self._security_level_sendKey_id

    def encode(self) -> tuple[bytes, bytes]:
        return self.security_level_requestSeed_id.to_bytes(
            1, "big"
        ), self.security_level_sendKey_id.to_bytes(1, "big")
