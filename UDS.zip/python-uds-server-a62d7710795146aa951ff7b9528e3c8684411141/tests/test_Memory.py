import pytest

from models import Memory, AddressLength


@pytest.fixture
def create_default_test_frame():
    mem = Memory(AddressLength.bit_32)
    mem.add_frame(512, 0x00000000, True)
    return mem


def test_read_no_frame():
    with pytest.raises(ValueError, match=r'No frame found for address \d+'):
        mem = Memory(AddressLength.bit_32)
        data = mem.read(0x00000001, 100)
        assert data is None


def test_write_no_frame():
    with pytest.raises(ValueError, match=r'No frame found for address \d+'):
        mem = Memory(AddressLength.bit_32)
        has_written = mem.write(0x00000001, b'\x00')
        assert has_written is None


def test_add_frame():
    mem = Memory(AddressLength.bit_32)
    mem.add_frame(512, 0x00000000, True)
    assert mem.frames[0].total_size == 512


def test_overlapping_frame():
    with pytest.raises(ValueError, match='Overlapping memory frames.'):
        mem = Memory(AddressLength.bit_32)
        mem.add_frame(512, 0x00000000, True)
        mem.add_frame(512, 0x00000001, True)


def test_overflowing_start_address():
    with pytest.raises(ValueError, match='Frame address length does not match configured memory address length.'):
        mem = Memory(AddressLength.bit_8)
        mem.add_frame(100, 0xAAAAAAAA, True)


def test_overflowing_total_size():
    with pytest.raises(ValueError, match=r'Total size exceeded possible value for \d+-byte address.'):
        mem = Memory(AddressLength.bit_8)
        mem.add_frame(1024, 0xAB, True)


def test_read(create_default_test_frame):
    read = create_default_test_frame.read(0x000000AA, 100)
    assert read is not None


def test_read_invalid_size(create_default_test_frame):
    with pytest.raises(ValueError, match=r'Attempt to over read frame.'):
        create_default_test_frame.read(0x000000AA, 513)


def test_read_invalid_address(create_default_test_frame):
    with pytest.raises(ValueError, match='Address length does not match configured memory address length.'):
        create_default_test_frame.read(0x100000000, 103)


def test_write_readonly(create_default_test_frame):
    with pytest.raises(PermissionError, match='Frame not writeable.'):
        mem = Memory(AddressLength.bit_32)
        mem.add_frame(512, 0x00000000, False)
        _ = mem.write(0x00000001, b'\xFF\xFF\xFF\xFF')


def test_write(create_default_test_frame):
    success = create_default_test_frame.write(0x00000001, b'\xFF\xFF\xFF\xFF')
    assert success
