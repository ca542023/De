// reload button
document.getElementById('reloadButton').addEventListener('click', function() {
    window.location.reload();
});


// auto reload every 30s
function autoReload() {
    location.reload();
}
setInterval(autoReload, 30000);