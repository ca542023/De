---
path: "/atoms/video/guide"
type: "intro"
level: "atoms"
title: "video"
---

The video element can be used with or without a caption.

<div class="frontend-kit__notification a-notification -neutral"><i class="a-icon ui-ic-alert-error"></i><div class="a-notification__content">
Ensure that each video has a <code>track</code> for caption. This is essential for deaf users to follow along. More informations can be found <a href="https://dequeuniversity.com/rules/axe/2.1/video-caption" target="_self">here</a>.